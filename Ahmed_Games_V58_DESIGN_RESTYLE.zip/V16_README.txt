Ahmed Games v16 - Update Ready

1) التطبيق الآن لديه مركز ألعاب remote catalog.
2) إضافة لعبة جديدة لاحقًا يمكن أن تتم من جدول public.ag_games بدون إصدار APK جديد، بشرط أن تكون اللعبة مستضافة على HTTPS وتكون game_url متاحة.
3) تحديث APK نفسه يتم برفع إصدار جديد إلى Google Play مع versionCode أعلى. داخل التطبيق يوجد فحص لإصدار أحدث من ag_app_config.
4) نفّذ SUPABASE_V16_UPDATES.sql في SQL Editor.
5) غيّر latest_version وupdate_url عند كل إصدار Android جديد.

ملاحظة: الصور/الأسماء الحقيقية للاعبين تحتاج حقوق استخدام مناسبة قبل النشر التجاري.
