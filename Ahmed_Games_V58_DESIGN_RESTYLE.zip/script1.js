
const SUPABASE_URL = "https://jkccqbaqurkhgbttrdks.supabase.co";
const SUPABASE_KEY = "sb_publishable_CLQp4K0eb3aVP-15m5JTBA_N0w9O9uP";
const supabaseClient = window.supabase.createClient(SUPABASE_URL, SUPABASE_KEY, {
  auth:{persistSession:true,autoRefreshToken:true,detectSessionInUrl:true,storage:window.localStorage}
});
