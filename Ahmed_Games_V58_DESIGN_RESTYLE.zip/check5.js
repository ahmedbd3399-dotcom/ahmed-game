
/* ================= AHMED GAMES USERNAME AUTH - STABLE LOCAL ================= */
(function(){
  const USERS_KEY='ag_local_users_v4';
  const CURRENT_KEY='ag_current';

  function users(){try{return JSON.parse(localStorage.getItem(USERS_KEY)||'{}')}catch(e){return {}}}
  function saveUsers(u){localStorage.setItem(USERS_KEY,JSON.stringify(u))}
  function clean(v){return String(v||'').trim().toLowerCase()}
  function validUsername(u){return /^[a-z0-9_]{3,18}$/i.test(u)}
  async function hash(text){
    try{
      const b=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(text));
      return Array.from(new Uint8Array(b)).map(x=>x.toString(16).padStart(2,'0')).join('');
    }catch(e){return btoa(unescape(encodeURIComponent(text)))}
  }
  function current(){try{return JSON.parse(localStorage.getItem(CURRENT_KEY)||'null')}catch(e){return null}}
  function setCurrent(u){
    localStorage.setItem(CURRENT_KEY,JSON.stringify(u));
    localStorage.setItem('ag_saved_username',u.username||'');
  }

  // IMPORTANT: account creation is local-first and never depends on a Supabase
  // "rooms" row. This prevents room/RLS errors from breaking registration.
  // Cross-device global uniqueness requires a dedicated backend user table/RPC;
  // the app does not pretend that the rooms table is an account database.

  window.authMode=function(k){
    window.authKind=k;
    document.getElementById('loginTab')?.classList.toggle('active',k==='login');
    document.getElementById('signupTab')?.classList.toggle('active',k==='signup');
    document.getElementById('displayName')?.classList.toggle('hidden',k==='login');
    const t=document.getElementById('authTitle');
    if(t)t.innerHTML='<h2>'+(k==='login'?'👤 تسجيل الدخول':'🆕 إنشاء حساب')+'</h2>';
    const m=document.getElementById('authMsg'); if(m)m.textContent='';
  };

  window.authKind='login';

  window.showAuth=function(){
    const el=document.getElementById('auth');
    if(!el)return;
    el.classList.remove('hidden');
    authMode(window.authKind||'login');
    const saved=localStorage.getItem('ag_saved_username')||'';
    const inp=document.getElementById('username');
    if(inp&&!inp.value)inp.value=saved;
  };

  window.submitAuth=async function(){
    const username=clean(document.getElementById('username')?.value);
    const pass=document.getElementById('password')?.value||'';
    const displayName=(document.getElementById('displayName')?.value||'').trim()||username;
    const msg=document.getElementById('authMsg');
    const btn=document.querySelector('#auth button[onclick="submitAuth()"]');

    if(!validUsername(username)){
      if(msg)msg.textContent='اسم المستخدم: من 3 إلى 18 حرفًا إنجليزيًا أو أرقامًا أو _.';
      return;
    }
    if(pass.length<6){
      if(msg)msg.textContent='كلمة السر لازم تكون 6 أحرف أو أكثر.';
      return;
    }

    if(btn){btn.disabled=true;btn.textContent='جاري الدخول...';}
    try{
      const db=users();

      if(window.authKind==='signup'){
        if(db[username]){
          if(msg)msg.textContent='اسم المستخدم ده مستخدم بالفعل على هذا الجهاز.';
          return;
        }

        const passHash=await hash(pass);
        db[username]={
          username,
          name:displayName,
          passHash,
          createdAt:Date.now()
        };
        saveUsers(db);
        setCurrent({username,name:displayName,local:true});
        if(msg)msg.textContent='تم إنشاء الحساب بنجاح وحفظه على الجهاز ✅';
      }else{
        const rec=db[username];
        if(!rec){
          if(msg)msg.textContent='الحساب غير موجود على هذا الجهاز. استخدم "إنشاء حساب" أولًا.';
          return;
        }
        const passHash=await hash(pass);
        if(rec.passHash!==passHash && rec.pass!==pass){
          if(msg)msg.textContent='كلمة السر غير صحيحة.';
          return;
        }
        setCurrent({username,name:rec.name||username,local:true});
        if(msg)msg.textContent='تم تسجيل الدخول والحساب محفوظ ✅';
      }

      window.AHMED_GAMES_AUTH_TOKEN='';
      window.renderUser?.();
      if(typeof window.setupIdentity==='function')window.setupIdentity();
      setTimeout(()=>document.getElementById('auth')?.classList.add('hidden'),350);
    }catch(e){
      if(msg)msg.textContent='حصل خطأ غير متوقع. جرّب مرة ثانية.';
      console.error('Ahmed Games auth error',e);
    }finally{
      if(btn){btn.disabled=false;btn.textContent='متابعة';}
    }
  };

  window.renderUser=function(){
    const u=current(), box=document.getElementById('userBox');
    if(!box)return;
    if(u){
      const n=String(u.name||u.username||'لاعب').replace(/[<>]/g,'');
      box.innerHTML='<span class="gold">👤 '+n+'</span> <button class="dark" onclick="logout()">خروج</button>';
    }else{
      box.innerHTML='<button class="blue" onclick="showAuth()">تسجيل الدخول</button>';
    }
  };

  window.logout=function(){
    localStorage.removeItem(CURRENT_KEY);
    window.AHMED_GAMES_AUTH_TOKEN='';
    window.renderUser?.();
    location.reload();
  };

  window.renderUser?.();
  const saved=localStorage.getItem('ag_saved_username');
  if(saved){
    const i=document.getElementById('username');
    if(i)i.value=saved;
  }
})();

