
/* ================= AHMED GAMES V22 MODES ================= */
(function(){
  let selectedPlayMode="ai";
  let selectedAuctionType="5";

  window.openPlaySetup=function(kind){
    selectedPlayMode=kind;
    document.getElementById("playSetup")?.classList.remove("hidden");
    document.getElementById("competitiveMode")?.classList.toggle("active",kind==="competitive");
    document.getElementById("aiModeChoice")?.classList.toggle("active",kind==="ai");
    document.getElementById("competitiveSetup")?.classList.toggle("hidden",kind!=="competitive");
    document.getElementById("aiSetup")?.classList.toggle("hidden",kind!=="ai");
    document.getElementById("setupHeading").textContent=kind==="competitive"?"اختار نوع المزاد للأونلاين":"اختار نوع المزاد ضد الذكاء الاصطناعي";
  };
  window.closePlaySetup=function(){
    document.getElementById("playSetup")?.classList.add("hidden");
    document.getElementById("competitiveMode")?.classList.remove("active");
    document.getElementById("aiModeChoice")?.classList.remove("active");
  };
  window.selectAuctionType=function(t){
    selectedAuctionType=t;
    mode=t;
    document.querySelectorAll(".auctionType").forEach(x=>x.classList.remove("active"));
    document.getElementById(t==="5"?"setup5":t==="11"?"setup11":"setupHidden")?.classList.add("active");
  };

  window.createSelectedRoom=async function(){
    mode=selectedAuctionType;
    const msg=document.getElementById("roomSetupMsg");
    if(msg)msg.textContent="جاري إنشاء الغرفة...";
    if(typeof window.createRoom==="function") await window.createRoom();
  };
  window.joinSelectedRoom=async function(){
    mode=selectedAuctionType;
    const msg=document.getElementById("roomSetupMsg");
    if(msg)msg.textContent="جاري دخول الغرفة...";
    if(typeof window.joinRoom==="function") await window.joinRoom();
  };

  // Local AI auction. This replaces the old broken/local starter while preserving the original UI.
  function aiStatsFor(p){
    const r=p.rate||70;
    return {PAC:Math.min(99,Math.max(50,r-2)),SHO:Math.min(99,Math.max(45,r+1)),
      PAS:Math.min(99,Math.max(45,r-1)),DRI:Math.min(99,Math.max(45,r)),
      DEF:p.pos==="DEF"?Math.min(99,r):Math.max(35,r-22),PHY:Math.min(99,Math.max(45,r+2))};
  }
  function renderLocalCard(p,big=false){
    const old=p.stats;p.stats=old||aiStatsFor(p);
    const out=cardHTML(p,big);
    if(old===undefined) delete p.stats; else p.stats=old;
    return out;
  }
  function maskLocalHidden(){
    const box=document.getElementById("auctionCard");
    if(!box)return;
    const p=window.current;
    box.innerHTML=renderLocalCard(p,true);
    const card=box.querySelector(".player-card");
    if(card){
      card.classList.add("hiddenCard");
      const name=card.querySelector(".pc-name"); if(name)name.textContent="اللاعب الخفي";
      const rating=card.querySelector(".rating"); if(rating)rating.textContent="?";
      const pos=card.querySelector(".position"); if(pos)pos.textContent="???";
      const stats=card.querySelector(".pc-stats"); if(stats)stats.innerHTML="<span>؟<small>PAC</small></span><span>؟<small>SHO</small></span><span>؟<small>PAS</small></span><span>؟<small>DRI</small></span><span>؟<small>DEF</small></span><span>؟<small>PHY</small></span>";
    }
  }
  function localNextPlayer(){
    const pool=players.filter(p=>!soldPlayers.has(p.id));
    if(!pool.length || team.length>=maxPlayers){
      active=false;clearInterval(clock);log("info","🏁 خلص المزاد — تشكيلتك اكتملت.");
      return;
    }
    const p=pool[Math.floor(Math.random()*pool.length)];
    current=p;currentBid=1;lastBidder=null;active=true;seconds=20;hintNo=0;
    auctionRound++;
    document.getElementById("round").textContent="الجولة "+auctionRound+" • "+(mode==="11"?"11 لاعب":mode==="5"?"5 لاعيبة":"اللاعب الخفي");
    document.getElementById("hiddenControls")?.classList.toggle("hidden",mode!=="hidden");
    if(mode==="hidden")maskLocalHidden(); else document.getElementById("auctionCard").innerHTML=renderLocalCard(p,true);
    document.getElementById("price").textContent="1";
    document.getElementById("timer").textContent="20";
    document.getElementById("turn").textContent="دورك";
    document.getElementById("bid").value=2;
    clearInterval(clock);
    clock=setInterval(()=>{
      seconds--;
      const t=document.getElementById("timer");if(t)t.textContent=seconds;
      if(seconds<=0){clearInterval(clock);active=false;resolveAuction();}
    },1000);
  }
  window.nextPlayer=localNextPlayer;

  window.startAuction=function(){
    budget=mode==="11"?200:100;
    maxPlayers=mode==="11"?11:5;
    team=[];stage=0;soldPlayers=new Set();auctionRound=0;hintNo=0;
    opponent={name:"🤖 الخصم الذكي",money:budget,style:Math.random()*3+1,avatar:"🤖",team:[]};
    opponentTeam=[];
    document.getElementById("home")?.classList.add("hidden");
    document.getElementById("lobby")?.classList.add("hidden");
    document.getElementById("game")?.classList.remove("hidden");
    document.getElementById("teamPanel")?.classList.remove("hidden");
    document.getElementById("matchPanel")?.classList.remove("hidden");
    document.getElementById("money").textContent=budget;
    document.getElementById("team").innerHTML="";
    document.getElementById("opponentTeam").innerHTML="";
    document.getElementById("feed").innerHTML="";
    log("info","🤖 بدأت مباراة ضد الذكاء الاصطناعي — "+(mode==="11"?"مزاد الـ11 لاعب":mode==="5"?"مزاد الخمس لاعيبة":"مزاد اللاعب الخفي"));
    localNextPlayer();
  };

  // Make the old choose buttons harmless and keep the new chooser as the source of truth.
  const oldChoose=window.choose;
  window.choose=function(x){selectedAuctionType=x;mode=x;if(oldChoose)try{oldChoose(x)}catch(e){}};

  // Hidden auction hints: useful information without revealing the identity.
  window.hint=function(){
    if(mode!=="hidden"||!current)return;
    hintNo++;
    const hints=document.getElementById("hints"); if(!hints)return;
    const list=[
      "المركز: "+(current.pos==="FWD"?"مهاجم":current.pos==="MID"?"وسط":"دفاع/حارس"),
      "الجنسية: "+current.flag,
      "التقييم التقريبي: "+(current.rate>=90?"نجم قوي جدًا":current.rate>=80?"لاعب قوي":"لاعب متوسط"),
      "اللاعب من قاعدة كرة القدم العالمية 🌍"
    ];
    const h=list[Math.min(hintNo-1,list.length-1)];
    hints.innerHTML+="<div class='notice' style='margin-top:6px'>🔎 "+h+"</div>";
  };

  // Override online auction renderer so hidden mode never exposes the real photo/name.
  const oldOnlineRender=window.renderOnlineAuction;
  // The actual function is closure-scoped in the live-online IIFE, so use CSS masking based on state.
  const hiddenStyle=document.createElement("style");
  hiddenStyle.textContent=".online-hidden-card .pc-photo img{display:none!important}.online-hidden-card .pc-photo:before{content:'❓';font-size:92px;display:grid;place-items:center;height:100%}.online-hidden-card .pc-name{font-size:0}.online-hidden-card .pc-name:after{content:'اللاعب الخفي';font-size:18px}.online-hidden-card .rating{font-size:0}.online-hidden-card .rating:after{content:'?';font-size:34px}.online-hidden-card .position{font-size:0}.online-hidden-card .position:after{content:'???';font-size:14px}.online-hidden-card .pc-stats{opacity:.35}";
  document.head.appendChild(hiddenStyle);

  // Periodically apply online hidden mask after realtime renders.
  setInterval(()=>{
    const s=window.AhmedGamesOnline?.getState?.();
    const card=document.querySelector("#auctionCard .player-card");
    if(card)card.classList.toggle("online-hidden-card",!!s?.hidden);
  },300);

  // Better room-state mode display if a room was opened with the new chooser.
  window.v22GetMode=()=>({playMode:selectedPlayMode,auctionType:selectedAuctionType});
})();
