
/* Ahmed Games LIVE - direct Supabase REST connector (works from a local HTML file) */
window.AHMED_GAMES_CONFIG = {
  url: "https://jkccqbaqurkhgbttrdks.supabase.co",
  publishableKey: "sb_publishable_CLQp4K0eb3aVP-15m5JTBA_N0w9O9uP"
};

let agRealtimeChannel = null;
let agPollTimer = null;

function agHeaders(extra={}) {
  return Object.assign({
    "apikey": window.AHMED_GAMES_CONFIG.publishableKey,
    "Authorization": "Bearer " + (window.AHMED_GAMES_AUTH_TOKEN || window.AHMED_GAMES_CONFIG.publishableKey),
    "Content-Type": "application/json"
  }, extra);
}

function agApiUrl(path) {
  return window.AHMED_GAMES_CONFIG.url.replace(/\/+$/,"") + "/rest/v1/" + path;
}

window.agIsConfigured = function agIsConfigured() {
  const c=window.AHMED_GAMES_CONFIG;
  return !!(c && c.url && c.url.startsWith("https://") &&
            c.publishableKey && c.publishableKey.startsWith("sb_publishable_"));
}

async function agCreateOnlineRoom(roomCode, roomData, hostId) {
  if(!agIsConfigured()) return {ok:false,reason:"not_configured"};
  const attempts=[
    {code:String(roomCode), host_id:hostId, status:"waiting", state:roomData},
    {code:String(roomCode), state:roomData}
  ];
  let last=null;
  for(const body of attempts){
    try {
      const r=await fetch(agApiUrl("rooms"),{
        method:"POST", headers:agHeaders({"Prefer":"return=representation"}),
        body:JSON.stringify(body)
      });
      const data=await r.json().catch(()=>null);
      if(r.ok) return {ok:true,data:data?.[0]||data};
      last={message:data?.message||data?.hint||("HTTP "+r.status),details:data};
    } catch(e) { last={message:e.message}; }
  }
  return {ok:false,error:last||{message:"تعذر إنشاء الغرفة"}};
}

async function agGetOnlineRoom(roomCode) {
  if(!agIsConfigured()) return {ok:false,reason:"not_configured"};
  try {
    const r=await fetch(agApiUrl("rooms?code=eq."+encodeURIComponent(roomCode)+"&select=*"),{
      headers:agHeaders()
    });
    const data=await r.json().catch(()=>null);
    if(!r.ok) return {ok:false,error:{message:data?.message||data?.hint||("HTTP "+r.status),details:data}};
    return {ok:true,data:data?.[0]||null};
  } catch(e) { return {ok:false,error:{message:e.message}}; }
}

async function agListPublicRooms() {
  if(!agIsConfigured()) return {ok:false,reason:"not_configured"};
  const urls=["rooms?status=eq.waiting&select=*&limit=100","rooms?select=*&limit=100"];
  let last=null;
  for(const path of urls){
    try {
      const r=await fetch(agApiUrl(path),{headers:agHeaders()});
      const data=await r.json().catch(()=>null);
      if(!r.ok){last={message:data?.message||data?.hint||("HTTP "+r.status),details:data};continue;}
      const rooms=(Array.isArray(data)?data:[]).filter(x=>{
        const st=x?.state||{};
        return st.visibility==="public" && !st.guest_id && st.phase==="lobby" && st.status!=="cancelled";
      });
      rooms.sort((a,b)=>new Date(b.created_at||0)-new Date(a.created_at||0));
      return {ok:true,data:rooms};
    } catch(e){last={message:e.message};}
  }
  return {ok:false,error:last||{message:"تعذر تحميل الغرف العامة"}};
}

async function agUpdateOnlineRoom(roomCode, roomData, extra={}, expectedVersion=null) {
  if(!agIsConfigured()) return {ok:false,reason:"not_configured"};
  const bodies=[Object.assign({state:roomData},extra),{state:roomData}];
  let last=null;
  for(const body of bodies){
    try {
      let path="rooms?code=eq."+encodeURIComponent(roomCode);
      if(expectedVersion!==null && Number.isFinite(Number(expectedVersion))){
        path += "&state->>version=eq."+encodeURIComponent(String(expectedVersion));
      }
      const r=await fetch(agApiUrl(path),{
        method:"PATCH", headers:agHeaders({"Prefer":"return=representation"}),
        body:JSON.stringify(body)
      });
      const data=await r.json().catch(()=>null);
      if(!r.ok){last={message:data?.message||data?.hint||("HTTP "+r.status),details:data};continue;}
      const row=Array.isArray(data)?data[0]:data;
      if(expectedVersion!==null && (!row || (Array.isArray(data)&&data.length===0))){
        // Fallback for projects where JSONB expression filters return no row.
        try{
          const rr=await fetch(agApiUrl("rooms?code=eq."+encodeURIComponent(roomCode)),{
            method:"PATCH",headers:agHeaders({"Prefer":"return=representation"}),body:JSON.stringify(body)
          });
          const dd=await rr.json().catch(()=>null);
          if(rr.ok){const row2=Array.isArray(dd)?dd[0]:dd;if(row2)return {ok:true,data:row2};}
        }catch(_e){}
        return {ok:false,conflict:true,error:{message:"حالة الغرفة اتغيرت قبل تنفيذ العملية."}};
      }
      return {ok:true,data:row};
    } catch(e){last={message:e.message};}
  }
  return {ok:false,error:last||{message:"فشل تحديث الغرفة"}};
}

function agSubscribeRoom(roomCode,onChange) {
  if(agPollTimer) clearInterval(agPollTimer);
  let lastVersion=null;
  const poll=async()=>{
    const r=await agGetOnlineRoom(roomCode);
    if(r.ok && r.data?.state) {
      const v=r.data.state.version;
      if(lastVersion===null || v!==lastVersion) {
        lastVersion=v;
        onChange(r.data);
      }
    }
  };
  poll();
  agPollTimer=setInterval(poll,500);
  return {unsubscribe:()=>clearInterval(agPollTimer)};
}

window.agSupabase = {
  __rest:true,
  from(){ throw new Error("Direct Supabase client disabled; use LIVE REST connector."); },
  removeChannel(){},
  channel(){ return null; }
};

