
const players = [
["Gianluigi Buffon","GK",94,"🇮🇹"],["Manuel Neuer","GK",92,"🇩🇪"],["Iker Casillas","GK",93,"🇪🇸"],["Lev Yashin","GK",96,"🇷🇺"],["Alisson","GK",89,"🇧🇷"],["Peter Schmeichel","GK",92,"🇩🇰"],["Oliver Kahn","GK",91,"🇩🇪"],["Edwin van der Sar","GK",92,"🇳🇱"],["Dino Zoff","GK",94,"🇮🇹"],["Essam El Hadary","GK",88,"🇪🇬"],
["Paolo Maldini","DEF",96,"🇮🇹"],["Franz Beckenbauer","DEF",96,"🇩🇪"],["Sergio Ramos","DEF",94,"🇪🇸"],["Virgil van Dijk","DEF",92,"🇳🇱"],["Roberto Carlos","DEF",95,"🇧🇷"],["Cafu","DEF",94,"🇧🇷"],["Alessandro Nesta","DEF",94,"🇮🇹"],["Carles Puyol","DEF",92,"🇪🇸"],["Fabio Cannavaro","DEF",93,"🇮🇹"],["Philipp Lahm","DEF",93,"🇩🇪"],["Giorgio Chiellini","DEF",90,"🇮🇹"],["Ashley Cole","DEF",91,"🇬🇧"],["Wael Gomaa","DEF",88,"🇪🇬"],
["Zinedine Zidane","MID",97,"🇫🇷"],["Diego Maradona","MID",98,"🇦🇷"],["Johan Cruyff","MID",96,"🇳🇱"],["Andrés Iniesta","MID",95,"🇪🇸"],["Xavi","MID",95,"🇪🇸"],["Luka Modrić","MID",94,"🇭🇷"],["Kevin De Bruyne","MID",94,"🇧🇪"],["Rodri","MID",93,"🇪🇸"],["Ronaldinho","MID",96,"🇧🇷"],["Michel Platini","MID",96,"🇫🇷"],["Kaká","MID",94,"🇧🇷"],["Steven Gerrard","MID",92,"🇬🇧"],["Frank Lampard","MID",92,"🇬🇧"],["Mohamed Aboutrika","MID",91,"🇪🇬"],
["Lionel Messi","FWD",99,"🇦🇷"],["Cristiano Ronaldo","FWD",99,"🇵🇹"],["Pelé","FWD",99,"🇧🇷"],["Ronaldo Nazário","FWD",97,"🇧🇷"],["Ronaldinho","FWD",96,"🇧🇷"],["Neymar","FWD",95,"🇧🇷"],["Mohamed Salah","FWD",91,"🇪🇬"],["Kylian Mbappé","FWD",97,"🇫🇷"],["Erling Haaland","FWD",95,"🇳🇴"],["Thierry Henry","FWD",96,"🇫🇷"],["Zlatan Ibrahimović","FWD",93,"🇸🇪"],["Hossam Hassan","FWD",90,"🇪🇬"],["George Weah","FWD",94,"🇱🇷"],["Marco van Basten","FWD",96,"🇳🇱"],["Gabriel Batistuta","FWD",94,"🇦🇷"],["Samuel Eto'o","FWD",94,"🇨🇲"],["Luis Suárez","FWD",93,"🇺🇾"]
,
["Thibaut Courtois","GK",92,"🇧🇪"],["Jan Oblak","GK",91,"🇸🇮"],["Emiliano Martínez","GK",90,"🇦🇷"],["Keylor Navas","GK",89,"🇨🇷"],["Marc-André ter Stegen","GK",90,"🇩🇪"],["David de Gea","GK",88,"🇪🇸"],
["John Terry","DEF",93,"🇬🇧"],["Rio Ferdinand","DEF",92,"🇬🇧"],["Nemanja Vidić","DEF",92,"🇷🇸"],["Gerard Piqué","DEF",90,"🇪🇸"],["Marcelo","DEF",92,"🇧🇷"],["Dani Alves","DEF",93,"🇧🇷"],["Javier Zanetti","DEF",93,"🇦🇷"],["Lilian Thuram","DEF",92,"🇫🇷"],["Virgil van Dijk","DEF",92,"🇳🇱"],["Ronald Koeman","DEF",94,"🇳🇱"],["Daniel Passarella","DEF",94,"🇦🇷"],["Marcel Desailly","DEF",93,"🇫🇷"],["Ricardo Carvalho","DEF",90,"🇵🇹"],["Trent Alexander-Arnold","DEF",87,"🇬🇧"],
["Toni Kroos","MID",93,"🇩🇪"],["Andrea Pirlo","MID",94,"🇮🇹"],["Paul Scholes","MID",92,"🇬🇧"],["Patrick Vieira","MID",93,"🇫🇷"],["Claude Makélélé","MID",91,"🇫🇷"],["Yaya Touré","MID",90,"🇨🇮"],["Steven Gerrard","MID",92,"🇬🇧"],["David Beckham","MID",93,"🇬🇧"],["Luis Figo","MID",95,"🇵🇹"],["Rivaldo","MID",95,"🇧🇷"],["Sócrates","MID",94,"🇧🇷"],["Gheorghe Hagi","MID",93,"🇷🇴"],["Zico","MID",96,"🇧🇷"],["Lothar Matthäus","MID",95,"🇩🇪"],["Bastian Schweinsteiger","MID",89,"🇩🇪"],["Mesut Özil","MID",90,"🇩🇪"],["Cesc Fàbregas","MID",89,"🇪🇸"],["Mohamed Elneny","MID",78,"🇪🇬"],
["Karim Benzema","FWD",93,"🇫🇷"],["Robert Lewandowski","FWD",96,"🇵🇱"],["Kylian Mbappé","FWD",97,"🇫🇷"],["Erling Haaland","FWD",95,"🇳🇴"],["Harry Kane","FWD",94,"🇬🇧"],["Luis Suárez","FWD",93,"🇺🇾"],["Sadio Mané","FWD",91,"🇸🇳"],["Riyad Mahrez","FWD",88,"🇩🇿"],["Eden Hazard","FWD",91,"🇧🇪"],["Gareth Bale","FWD",90,"🇬🇧"],["Arjen Robben","FWD",94,"🇳🇱"],["Franck Ribéry","FWD",91,"🇫🇷"],["Wayne Rooney","FWD",93,"🇬🇧"],["Didier Drogba","FWD",93,"🇨🇮"],["Samuel Eto'o","FWD",94,"🇨🇲"],["Kenny Dalglish","FWD",94,"🇬🇧"],["Ferenc Puskás","FWD",98,"🇭🇺"],["Eusébio","FWD",97,"🇵🇹"],["Gerd Müller","FWD",97,"🇩🇪"],["Romário","FWD",96,"🇧🇷"],["Hugo Sánchez","FWD",94,"🇲🇽"],["Andriy Shevchenko","FWD",94,"🇺🇦"],["George Best","FWD",96,"🇬🇧"],["Dennis Bergkamp","FWD",94,"🇳🇱"],["Ruud van Nistelrooy","FWD",93,"🇳🇱"],["Robin van Persie","FWD",92,"🇳🇱"],["Sergio Agüero","FWD",93,"🇦🇷"],["Fernando Torres","FWD",91,"🇪🇸"],["David Villa","FWD",93,"🇪🇸"],["Antoine Griezmann","FWD",91,"🇫🇷"],["Vinícius Júnior","FWD",92,"🇧🇷"],["Jude Bellingham","MID",93,"🇬🇧"],["Pedri","MID",88,"🇪🇸"],["Bukayo Saka","FWD",88,"🇬🇧"],["Phil Foden","MID",89,"🇬🇧"],["Lamine Yamal","FWD",90,"🇪🇸"],["Victor Osimhen","FWD",90,"🇳🇬"],["Khvicha Kvaratskhelia","FWD",88,"🇬🇪"],["Bernardo Silva","MID",90,"🇵🇹"],["Bruno Fernandes","MID",90,"🇵🇹"],["Casemiro","MID",89,"🇧🇷"],["N'Golo Kanté","MID",89,"🇫🇷"],["Thiago Silva","DEF",88,"🇧🇷"],["Raphaël Varane","DEF",88,"🇫🇷"],["Éder Militão","DEF",86,"🇧🇷"],["Achraf Hakimi","DEF",87,"🇲🇦"],["Andrew Robertson","DEF",86,"🇬🇧"],["Alphonso Davies","DEF",86,"🇨🇦"],["Salah Hassan","FWD",80,"🇪🇬"],["Ahmed Hassan","MID",84,"🇪🇬"],["Mido","FWD",85,"🇪🇬"],["Hany Ramzy","DEF",80,"🇪🇬"],["Hazem Emam","MID",85,"🇪🇬"],["Emad Moteab","FWD",84,"🇪🇬",
["Lionel Messi","FWD",98,"🇦🇷"],["Cristiano Ronaldo","FWD",98,"🇵🇹"],["Neymar Jr","FWD",95,"🇧🇷"],["Vinícius Júnior","FWD",95,"🇧🇷"],["Jude Bellingham","MID",94,"🏴"],["Bukayo Saka","FWD",90,"🏴"],["Phil Foden","MID",91,"🏴"],["Cole Palmer","MID",90,"🏴"],["Declan Rice","MID",88,"🏴"],["Martin Ødegaard","MID",90,"🇳🇴"],["Bernardo Silva","MID",91,"🇵🇹"],["Bruno Fernandes","MID",91,"🇵🇹"],["Rúben Dias","DEF",90,"🇵🇹"],["William Saliba","DEF",89,"🇫🇷"],["Trent Alexander-Arnold","DEF",88,"🏴"],["Andrew Robertson","DEF",87,"🏴"],["Thibaut Courtois","GK",93,"🇧🇪"],["Mike Maignan","GK",89,"🇫🇷"],["Jan Oblak","GK",91,"🇸🇮"],["Emiliano Martínez","GK",89,"🇦🇷"],["Lautaro Martínez","FWD",91,"🇦🇷"],["Victor Osimhen","FWD",90,"🇳🇬"],["Harry Kane","FWD",94,"🏴"],["Son Heung-min","FWD",91,"🇰🇷"],["Rodrygo","FWD",89,"🇧🇷"],["Rafael Leão","FWD",89,"🇵🇹"],["Khvicha Kvaratskhelia","FWD",88,"🇬🇪"],["Victor Boniface","FWD",84,"🇳🇬"],["Jamal Musiala","MID",91,"🇩🇪"],["Florian Wirtz","MID",91,"🇩🇪"],["Toni Kroos","MID",94,"🇩🇪"],["Thomas Müller","FWD",90,"🇩🇪"],["Joshua Kimmich","MID",90,"🇩🇪"],["Antonio Rüdiger","DEF",89,"🇩🇪"],["Éder Militão","DEF",88,"🇧🇷"],["Achraf Hakimi","DEF",89,"🇲🇦"],["Theo Hernández","DEF",88,"🇫🇷"],["Frenkie de Jong","MID",89,"🇳🇱"],["Pedri","MID",89,"🇪🇸"],["Gavi","MID",86,"🇪🇸"],["Lamine Yamal","FWD",88,"🇪🇸"],["Dani Olmo","MID",86,"🇪🇸"],["Mikel Oyarzabal","FWD",85,"🇪🇸"],["Antoine Griezmann","FWD",91,"🇫🇷"],["Ousmane Dembélé","FWD",89,"🇫🇷"],["Eduardo Camavinga","MID",87,"🇫🇷"],["Aurélien Tchouaméni","MID",87,"🇫🇷"],["Mike Maignan","GK",89,"🇫🇷"],["Romelu Lukaku","FWD",88,"🇧🇪"],["Kevin De Bruyne","MID",94,"🇧🇪"],["Mohamed Salah","FWD",91,"🇪🇬"],["Omar Marmoush","FWD",86,"🇪🇬"],["Mahmoud Hassan Trezeguet","FWD",82,"🇪🇬"],["Mostafa Mohamed","FWD",80,"🇪🇬"],["Mohamed Elneny","MID",78,"🇪🇬"],["Ahmed Hegazi","DEF",79,"🇪🇬"],["Mohamed Abdelmonem","DEF",82,"🇪🇬"],["Emam Ashour","MID",82,"🇪🇬"],["Marwan Attia","MID",80,"🇪🇬"],["Rami Rabia","DEF",78,"🇪🇬"],["Hossam Hassan","FWD",90,"🇪🇬"],["Ahmed Hassan","MID",89,"🇪🇬"],["Wael Gomaa","DEF",88,"🇪🇬"],["Essam El Hadary","GK",88,"🇪🇬"] ]].map((x,i)=>({id:i,name:x[0],pos:x[1],rate:x[2],flag:x[3],img:null}));
players.splice(0, players.length, ...players.filter((p,i,a)=>a.findIndex(v=>v.name===p.name)===i));

let mode="5", budget=100, maxPlayers=5, stage=0, current=null, currentBid=1, active=false, seconds=20, clock=null, lastBidder=null, team=[], hintNo=0;
let opponent={name:"الخصم",money:100,style:2,avatar:"🤖",team:[]};
let opponentTeam=[];
let soldPlayers=new Set();
let auctionRound=0;

// V44: real pitch placement. V43 called place() after winning, but place() was missing.
function place(p){
  const slots={GK:["gk"],DEF:["d1","d2","d3"],MID:["m1","m2","m3"],FWD:["f1","f2","f3"]};
  const all=["gk","d1","d2","d3","m1","m2","m3","f1","f2","f3"];
  all.forEach(id=>{const el=document.getElementById(id);if(el)el.innerHTML="";});
  const taken={GK:0,DEF:0,MID:0,FWD:0};
  (team||[]).slice(0,11).forEach(x=>{
    const arr=slots[x.pos]||slots.FWD;
    const idx=taken[x.pos]||0;
    const id=arr[Math.min(idx,arr.length-1)];
    taken[x.pos]=(taken[x.pos]||0)+1;
    const el=document.getElementById(id); if(!el)return;
    const img=x.img?'<img src="'+x.img+'" onerror="this.style.display=\'none\'">':'⚽';
    el.innerHTML='<div class="picon">'+img+'</div><b>'+x.name+'</b>';
  });
}

const photoLoading=new Set();
const photoDone=new Set();
async function fetchWikiPhoto(p){
 if(!p||p.img||photoLoading.has(p.id)) return;
 photoLoading.add(p.id);
 const urls=[
   "https://en.wikipedia.org/api/rest_v1/page/summary/"+encodeURIComponent(p.name),
   "https://ar.wikipedia.org/api/rest_v1/page/summary/"+encodeURIComponent(p.name)
 ];
 for(const u of urls){
   try{
     const r=await fetch(u,{headers:{"Accept":"application/json"}});
     if(!r.ok) continue;
     const d=await r.json();
     const src=d?.thumbnail?.source||d?.originalimage?.source;
     if(src){p.img=src;break;}
   }catch(e){}
 }
 photoDone.add(p.id); photoLoading.delete(p.id);
 renderLibrary();
 if(current&&current.id===p.id) renderAuction();
}
function wikiImg(name){const p=players.find(x=>x.name===name);if(p)fetchWikiPhoto(p);}
let photoCursor=0;
function loadPhotoBatch(){
 const pending=players.filter(p=>!p.img&&!photoDone.has(p.id)&&!photoLoading.has(p.id)).slice(photoCursor,photoCursor+12);
 photoCursor+=pending.length;
 pending.forEach(p=>fetchWikiPhoto(p));
 if(players.some(p=>!p.img&&!photoDone.has(p.id))) setTimeout(loadPhotoBatch,700);
}
function renderLibrary(){
 const lib=document.getElementById("library");
 if(lib) lib.innerHTML=players.map(p=>cardHTML(p,false)).join("");
 setTimeout(loadPhotoBatch,80);
}
async function searchGlobalPlayer(){
 const q=document.getElementById("playerSearch").value.trim();
 const box=document.getElementById("searchResult");
 if(!q){box.innerHTML='<div class="notice">اكتب اسم لاعب أولًا.</div>';return;}
 box.innerHTML='<div class="notice">🔎 جاري البحث...</div>';
 try{
   const url='https://www.thesportsdb.com/api/v1/json/123/searchplayers.php?p='+encodeURIComponent(q);
   const r=await fetch(url); const d=await r.json(); const x=d?.player?.[0];
   if(!x){box.innerHTML='<div class="notice danger">ملقتش لاعب بالاسم ده. جرّب الاسم بالإنجليزي.</div>';return;}
   let p=players.find(v=>v.name.toLowerCase()===String(x.strPlayer||'').toLowerCase());
   if(!p){
     p={id:'api_'+x.idPlayer,name:x.strPlayer||q,pos:(x.strPosition||'FWD').includes('Goalkeeper')?'GK':((x.strPosition||'').includes('Defender')?'DEF':((x.strPosition||'').includes('Midfielder')?'MID':'FWD')),rate:Math.min(99,Math.max(70,Math.round(80+Math.random()*18))),flag:'⚽',img:x.strCutout||x.strThumb||x.strRender||null,stats:{PAC:85,SHO:85,PAS:85,DRI:85,DEF:70,PHY:80}};
     players.push(p);
   } else if(!p.img) p.img=x.strCutout||x.strThumb||x.strRender||null;
   box.innerHTML='<div class="notice success">✅ تم العثور على <b>'+p.name+'</b> بصورته. تمت إضافته لقاعدة اللعبة.</div>';
   renderLibrary();
 }catch(e){box.innerHTML='<div class="notice danger">تعذر الاتصال بقاعدة اللاعبين. جرّب مرة أخرى.</div>';}
}
function cardHTML(p,big){
 const stats=p.stats||{PAC:Math.max(55,p.rate-8),SHO:Math.max(55,p.rate-3),PAS:Math.max(55,p.rate-4),DRI:Math.max(55,p.rate-2),DEF:p.pos==="DEF"?Math.min(99,p.rate):Math.max(35,p.rate-20),PHY:Math.max(55,p.rate-1)};
 const tier=p.rate>=90?"card-gold":(p.rate>=80?"card-silver":"card-bronze");
 return `<div class="player-card ${tier} ${big?"big-card":""}" data-player-name="${String(p.name).replace(/"/g,"&quot;")}">
 <div class="pc-top"><span><span class="rating">${p.rate}</span><br><span class="position">${p.pos}</span></span><span class="flag">${p.flag}</span></div>
 <div class="pc-photo">${p.img?`<img src="${p.img}" loading="lazy" onerror="this.remove();this.parentNode.querySelector('.fallback').style.display='grid'">`:""}<span class="fallback" style="${p.img?"display:none":""}">⚽</span></div>
 <div class="pc-name">${p.name}</div>
 <div class="pc-stats"><span><b>${stats.PAC}</b>PAC</span><span><b>${stats.SHO}</b>SHO</span><span><b>${stats.PAS}</b>PAS</span><span><b>${stats.DRI}</b>DRI</span><span><b>${stats.DEF}</b>DEF</span><span><b>${stats.PHY}</b>PHY</span></div>
 <div class="pc-brand">AHMED GAMES</div>
 </div>`;
}
function choose(x){mode=x;document.querySelectorAll(".mode").forEach(e=>e.classList.remove("active"));document.getElementById(x==="5"?"m5":x==="11"?"m11":"mh").classList.add("active")}
function showAuth(){document.getElementById("auth").classList.toggle("hidden")}
let authKind="login";
function authMode(k){authKind=k;document.getElementById("loginTab").classList.toggle("active",k==="login");document.getElementById("signupTab").classList.toggle("active",k==="signup");document.getElementById("displayName").classList.toggle("hidden",k==="login");document.getElementById("authTitle").innerHTML="<h2>"+(k==="login"?"👤 تسجيل الدخول":"🆕 إنشاء حساب")+"</h2>"}
function submitAuth(){
 let email=document.getElementById("email").value.trim().toLowerCase(), pass=document.getElementById("password").value, name=document.getElementById("displayName").value.trim()||email.split("@")[0];
 if(!email||!pass){document.getElementById("authMsg").textContent="اكتب البريد وكلمة السر.";return}
 let users=JSON.parse(localStorage.getItem("ag_users")||"{}");
 if(authKind==="signup"){
   if(users[email]){document.getElementById("authMsg").textContent="الحساب موجود بالفعل.";return}
   users[email]={email,pass,name};localStorage.setItem("ag_users",JSON.stringify(users));
 }else if(!users[email]||users[email].pass!==pass){document.getElementById("authMsg").textContent="بيانات الدخول غير صحيحة.";return}
 localStorage.setItem("ag_current",JSON.stringify(users[email]));renderUser();document.getElementById("auth").classList.add("hidden");
}
function renderUser(){
 let u=JSON.parse(localStorage.getItem("ag_current")||"null");
 document.getElementById("userBox").innerHTML=u?`<span class="gold">👤 ${u.name}</span> <button class="dark" onclick="logout()">خروج</button>`:`<button class="blue" onclick="showAuth()">تسجيل الدخول</button>`;
}
function logout(){localStorage.removeItem("ag_current");renderUser()}
function createRoom(){if(!localStorage.getItem("ag_current")){showAuth();return}let c=Math.floor(100000+Math.random()*900000);openRoom(c,true)}
function joinRoom(){if(!localStorage.getItem("ag_current")){showAuth();return}let c=document.getElementById("roomCodeInput").value.trim();if(!/^\d{6}$/.test(c)){alert("اكتب كود غرفة من 6 أرقام");return}openRoom(c,false)}
function openRoom(code,host){document.getElementById("home").classList.add("hidden");document.getElementById("lobby").classList.remove("hidden");document.getElementById("roomCodeView").textContent=code;document.getElementById("roomState").textContent=host?"أنت صاحب الغرفة — مستني أصحابك.":"دخلت الغرفة — مستني بداية المزاد.";let u=JSON.parse(localStorage.getItem("ag_current"));document.getElementById("roomMembers").innerHTML=[u?.name||"Ahmed","أبو الكورة 🤖","King 🤖"].map((x,i)=>`<div class="member"><b>${x}</b><br><span class="success">● جاهز</span></div>`).join("")}
async function exitRoom(){
  // Leave the current online room without affecting the rest of the game/account.
  try{
    if(window.AhmedGamesOnline && typeof window.AhmedGamesOnline.leaveRoom === "function"){
      await window.AhmedGamesOnline.leaveRoom();
      return;
    }
  }catch(e){ console.warn("leaveRoom",e); }
  document.getElementById("lobby")?.classList.add("hidden");
  document.getElementById("game")?.classList.add("hidden");
  document.getElementById("home")?.classList.remove("hidden");
}
window.exitRoom=exitRoom;
function beginRoom(){document.getElementById("lobby").classList.add("hidden");startAuction()}
function startAuction(){
 budget=mode==="5"?100:mode==="11"?200:100;maxPlayers=mode==="5"?5:mode==="11"?11:5;team=[];stage=0;soldPlayers=new Set();auctionRound=0;opponent.money=budget;opponent.team=[];opponentTeam=[];
 document.getElementById("game").classList.remove("hidden");document.getElementById("teamPanel").classList.remove("hidden");document.getElementById("matchPanel").classList.remove("hidden");document.getElementById("money").textContent=budget;opponentTeamHTML();nextPlayer();
}
function pool(){ return players.filter(p=>!soldPlayers.has(p.id)); }
function randomSamePositionPlayer(pos){
 let c=players.filter(p=>p.pos===pos&&!soldPlayers.has(p.id)&&p.id!==current?.id);
 if(!c.length)c=players.filter(p=>p.pos===pos&&p.id!==current?.id);
 if(!c.length)return null;
 const sorted=[...c].sort((a,b)=>a.rate-b.rate);
 const r=Math.random();
 const start=r<.30?0:r<.70?Math.floor(sorted.length*.25):Math.floor(sorted.length*.65);
 const end=r<.30?Math.max(1,Math.floor(sorted.length*.35)):r<.70?Math.max(start+1,Math.floor(sorted.length*.75)):sorted.length;
 return sorted[start+Math.floor(Math.random()*Math.max(1,end-start))];
}
function giveOpponentRandomPlayer(pos){
 const p=randomSamePositionPlayer(pos); if(!p)return;
 opponent.team.push({...p}); opponentTeam=opponent.team; soldPlayers.add(p.id);
 log("ai",`🎁 <b>${opponent.name}</b> أخد لاعب عشوائي في نفس المركز: <b>${p.name}</b> (${p.rate})`);
}
function opponentTeamHTML(){
 const box=document.getElementById("opponentTeam");
 if(!box)return;
 box.innerHTML=opponent.team.map(x=>`<div class="member">${x.img?`<img src="${x.img}" onerror="this.style.display='none'">`:"⚽"}<br><b>${x.name}</b><br><span class="muted">${x.pos} • ${x.rate}</span></div>`).join("");
}
function giveUserRandomPlayer(pos){
 const p=randomSamePositionPlayer(pos); if(!p)return;
 team.push({...p,cost:0,randomReward:true}); soldPlayers.add(p.id); place(p);
 document.getElementById("team").innerHTML=team.map(x=>`<div class="member">${x.img?`<img src="${x.img}" onerror="this.style.display='none'">`:"⚽"}<br><b>${x.name}</b><br><span class="muted">${x.pos} • ${x.rate}</span></div>`).join("");
 log("you",`🎁 جالك لاعب عشوائي في نفس المركز: <b>${p.name}</b> (${p.rate})`);
}

function renderAuction(){
 if(current) fetchWikiPhoto(current);document.getElementById("auctionCard").innerHTML=cardHTML(current,true);if(mode==="hidden"){document.querySelector(".big-card .pc-name").textContent="اللاعب الخفي";document.querySelector(".big-card .pc-rate").textContent="?";}}
function log(c,t){document.getElementById("feed").innerHTML=`<div class="msg ${c}">${t}</div>`+document.getElementById("feed").innerHTML}
let localTurn="user";
let localSlotIndex=0;
function myBid(valueOverride){
 if(!active)return;
 const input=document.getElementById("bid");
 if(Number.isFinite(Number(valueOverride)) && input) input.value=String(valueOverride);
 if(localTurn!=="user")return log("ai","⏳ استنى رد الخصم...");
 let v=parseInt(document.getElementById("bid").value);
 if(!v||v<=currentBid)return log("ai","❌ لازم تزيد عن "+currentBid+"M");
 if(v>budget)return log("ai","❌ ميزانيتك لا تكفي.");
 clearTimeout(aiBidTimer);
 currentBid=v;lastBidder="أنت";localTurn="ai";
 document.getElementById("price").textContent=v;
 document.getElementById("turn").textContent="🤖 الخصم بيفكر...";
 document.getElementById("bid").value=v+1;
 log("you","🔥 إنت رفعت إلى <b>"+v+"M</b>");
 aiBidTimer=setTimeout(opponentBid,700);
}
function add(n){
 const b=document.getElementById("bid");
 if(b)b.value=(currentBid||1)+n;
 myBid();
}
let aiBidTimer=null;
function scheduleAIBid(delay=900){
 clearTimeout(aiBidTimer);
 if(localTurn==="ai") aiBidTimer=setTimeout(opponentBid,delay);
}
function aiOpeningBid(){
  clearTimeout(aiBidTimer);
  if(!active || localTurn!=="ai" || lastBidder!==null)return;
  const maxOpp=Number(opponent.money||0);
  const rate=Number(current?.rate||70);
  const quality=Math.max(0,Math.min(25,rate-70));
  const willing=Math.min(maxOpp,Math.max(2,Math.floor(maxOpp*(0.34+quality/100))));
  if(willing<2){localTurn="user";document.getElementById("turn").textContent="دورك — زوّد الآن";return;}
  const opening=Math.min(willing,Math.max(2,Math.min(5,2+Math.floor(Math.random()*3))));
  currentBid=opening;lastBidder=opponent.name;localTurn="user";
  document.getElementById("price").textContent=currentBid;
  document.getElementById("turn").textContent="🤖 الخصم زايد — دورك";
  document.getElementById("bid").value=currentBid+1;
  log("ai","🤖 <b>"+opponent.name+"</b> بدأ المزايدة بـ <b>"+currentBid+"M</b>");
}
function opponentBid(){
  clearTimeout(aiBidTimer);
 if(!active || localTurn!=="ai" || lastBidder!=="أنت")return;
 const maxOpp=Number(opponent.money||0);
 if(maxOpp<=currentBid){
   log("ai","🤖 <b>"+opponent.name+" </b> ميزانيته لا تسمح بالمزيد.");
   localTurn="user";document.getElementById("turn").textContent="دورك — زوّد الآن";return;
 }
 const pressure=current?.rate||70;
 const maxWilling=Math.min(maxOpp,Math.max(currentBid+1,Math.floor(opponent.money*(0.48+Math.max(0,pressure-70)/220))));
 if(currentBid>=maxWilling){
   log("ai","🤖 <b>"+opponent.name+"</b> شايف السعر عالي ووقف.");
   localTurn="user";document.getElementById("turn").textContent="دورك — زوّد أو احسم";return;
 }
 const inc=Math.max(1,Math.floor(1+opponent.style+Math.random()*3));
 const next=Math.min(currentBid+inc,maxWilling,maxOpp);
 if(next>currentBid){
   currentBid=next;lastBidder=opponent.name;
   document.getElementById("price").textContent=currentBid;
   document.getElementById("turn").textContent="🤖 الخصم زايد — دورك";
   document.getElementById("bid").value=currentBid+1;
   log("ai","🤖 <b>"+opponent.name+" زاد إلى "+currentBid+"M</b>");
 }else{
   log("ai","🤖 <b>"+opponent.name+" </b> وقف المزايدة.");
 }
 localTurn="user";
}
function claim(){if(!active)return;if(currentBid<2)return log("ai","❌ لازم يكون فيه مزاد أولًا.");if(lastBidder!=="أنت")return log("ai","⚠️ أنت مش أعلى مزايد حاليًا. لازم تزايد.");win()}
function pass(){if(!active)return;active=false;clearInterval(clock);clearTimeout(aiBidTimer);log("ai","🚪 انسحبت. السيستم يحسم النتيجة.");setTimeout(resolveAuction,500)}
function resolveAuction(){
 if(!active && lastBidder===null)return;
 active=false;clearInterval(clock);clearTimeout(aiBidTimer);
 localSlotIndex++;
 if(lastBidder==="أنت"){
   log("you","🏆 <b>إنت كسبت "+current.name+" بـ "+currentBid+"M</b>");
   setTimeout(win,700);
 }else if(lastBidder===opponent.name){
   if(mode==="hidden")revealHiddenCard();
   opponent.money=Math.max(0,opponent.money-currentBid);
   opponent.team.push({...current,cost:currentBid});
   opponentTeam=opponent.team;
   soldPlayers.add(current.id);
   log("ai","🏆 <b>"+opponent.name+" كسب "+current.name+" بـ "+currentBid+"M</b>");
   setTimeout(()=>{log("info","🎲 لاعب عشوائي جديد داخل المزاد...");advance()},1000);
 }else{
   soldPlayers.add(current.id);
   log("info","⏱️ انتهى الوقت — لاعب جديد عشوائي.");
   setTimeout(advance,900);
 }
}
function win(){
 if(currentBid>budget){log("ai","❌ الميزانية لا تكفي.");return}
 if(mode==="hidden")revealHiddenCard();
 budget-=currentBid;document.getElementById("money").textContent=budget;
 team.push({...current,cost:currentBid});soldPlayers.add(current.id);place(current);opponentTeam=opponent.team;
 document.getElementById("team").innerHTML=team.map(p=>`<div class="member">${p.img?`<img src="${p.img}" onerror="this.style.display='none'">`:"⚽"}<br><b>${p.name}</b><br><span class="muted">${p.cost}M</span></div>`).join("");
 log("you","💰 تمت الصفقة: "+current.name+" أصبح عندك.");
 setTimeout(()=>{log("info","🎲 اللاعب التالي عشوائي...");advance()},1000);
}
function advance(){ if(team.length>=maxPlayers){log("info","🏁 انتهى المزاد.");return} nextPlayer(); }
function strength(t){
  if(!t.length)return 70;
  const avg=t.reduce((s,p)=>s+p.rate,0)/t.length;
  const bonus=t.length>=11?5:t.length*0.4;
  return avg+bonus;
}
function renderMatchTeams(){
  const render=t=>t.map(p=>`<div class="matchPlayer">${p.img?`<img src="${p.img}" onerror="this.style.display='none'">`:"⚽"}<div><b>${p.name}</b><br><span class="muted">${p.pos} • ${p.rate}</span></div></div>`).join("");
  document.getElementById("myMatchTeam").innerHTML=render(team);
  document.getElementById("oppMatchTeam").innerHTML=render(opponentTeam);
}
function playMatch(aiMode){
  if(team.length<5){
    alert("لازم تجمع 5 لاعبين على الأقل قبل المباراة.");
    return;
  }
  document.getElementById("matchPanel").classList.remove("hidden");
  opponentTeam=opponent.team.length?opponent.team:makeOpponentTeam();
  renderMatchTeams();
  matchMyScore=0;matchOppScore=0;
  document.getElementById("matchScore").textContent="إنت 0 — 0 الخصم";
  document.getElementById("matchEvents").innerHTML="";
  let my= strength(team)+(Math.random()*14-7);
  let op= strength(opponentTeam)+(Math.random()*14-7);
  if(aiMode){
    // AI mode makes the opponent adapt to the user's squad strength.
    op += Math.max(0,(my-op)*0.22);
    addMatchEvent("🤖 وضع الذكاء الاصطناعي شغال — الخصم بيعدّل أسلوبه حسب تشكيلتك.","info");
  }
  const events=[];
  const total=aiMode?7:5;
  for(let i=0;i<total;i++){
    const mine=Math.random() < my/(my+op);
    const chance=(mine?my:op)/(my+op)*0.34;
    if(Math.random()<chance){
      const scorer=mine?team[Math.floor(Math.random()*team.length)]:opponentTeam[Math.floor(Math.random()*opponentTeam.length)];
      if(mine)matchMyScore++; else matchOppScore++;
      events.push({min:Math.floor(5+Math.random()*86),mine,scorer});
    }
  }
  events.sort((a,b)=>a.min-b.min);
  let idx=0;
  const timer=setInterval(()=>{
    if(idx>=events.length){
      clearInterval(timer);
      document.getElementById("matchScore").textContent=`إنت ${matchMyScore} — ${matchOppScore} الخصم`;
      addMatchEvent(`🏁 انتهت المباراة: ${matchMyScore} - ${matchOppScore}`,"info");
      return;
    }
    const e=events[idx++];
    document.getElementById("matchScore").textContent=`إنت ${matchMyScore} — ${matchOppScore} الخصم`;
    addMatchEvent(`⚽ الدقيقة ${e.min}' — ${e.mine?"🔥 هدف لك":"🥅 هدف للخصم"} بواسطة <b>${e.scorer.name}</b>`,e.mine?"you":"ai");
  },700);
}
function addMatchEvent(t,c){document.getElementById("matchEvents").innerHTML=`<div class="msg ${c}">${t}</div>`+document.getElementById("matchEvents").innerHTML}
renderUser();renderLibrary();
