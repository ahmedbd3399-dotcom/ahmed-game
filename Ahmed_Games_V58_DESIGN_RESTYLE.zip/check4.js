
/* ================= AHMED GAMES LIVE ONLINE MODE ================= */
(function(){
  let onlineRoomCode=null, onlineIsHost=false, onlinePlayerId=null;
  let onlinePlayerName="Ahmed", onlineState=null, onlineVersion=0, onlineTimer=null;

  function getUser(){
    try{return JSON.parse(localStorage.getItem("ag_current")||"null");}
    catch(e){return null;}
  }
  function ensurePlayerId(){
    let id=localStorage.getItem("ag_player_id");
    if(!id){
      id=(window.crypto&&crypto.randomUUID)?crypto.randomUUID():
        "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g,c=>{
          const r=Math.random()*16|0,v=c==="x"?r:(r&3|8);return v.toString(16);
        });
      localStorage.setItem("ag_player_id",id);
    }
    return id;
  }
  function setupIdentity(){
    const u=getUser(); onlinePlayerId=ensurePlayerId(); onlinePlayerName=u?.name||u?.username||"Ahmed";
  }
  setupIdentity();

  function configured(){return window.agIsConfigured?window.agIsConfigured():(
    window.AHMED_GAMES_CONFIG?.url?.startsWith("https://") &&
    window.AHMED_GAMES_CONFIG?.publishableKey?.startsWith("sb_publishable_")
  );}

  // V42: fixed auction formation. For 5 players: GK -> DEF -> MID -> MID -> ST.
  // For 11 players: GK -> 4 DEF -> 4 MID -> 2 ST.
  function auctionRoleSequence(modeValue){
    return String(modeValue)==="11"
      ? ["GK","DEF","DEF","DEF","DEF","MID","MID","MID","MID","ST","ST"]
      : ["GK","DEF","MID","MID","ST"];
  }
  function pickAuctionPlayer(list, soldIds, modeValue, round){
    const seq=auctionRoleSequence(modeValue);
    const wanted=seq[Math.min(Number(round)||0,seq.length-1)];
    const available=(list||[]).filter(p=>!(soldIds||[]).includes(p.id));
    const exact=available.filter(p=>String(p.pos||"")===wanted);
    if(exact.length) return exact[Math.floor(Math.random()*exact.length)];
    // Never leave the auction blank if a database has an incomplete position pool.
    return available[Math.floor(Math.random()*available.length)]||null;
  }
  function auctionRoleLabel(pos){
    return pos==="GK"?"🧤 حارس مرمى":pos==="DEF"?"🛡️ مدافع":pos==="MID"?"🎯 لاعب وسط":"⚡ مهاجم";
  }

  function roomStateBase(code,modeValue){
    return {
      version:1,room_code:String(code),status:"waiting",
      host_id:onlinePlayerId,guest_id:null,host_name:onlinePlayerName,guest_name:null,
      mode:modeValue||window.mode||"5",visibility:window.selectedRoomVisibility||"private",budget:modeValue==="11"?200:100,
      maxPlayers:modeValue==="11"?11:5,phase:"lobby",turn:null,currentPlayerId:null,
      currentBid:1,lastBidderId:null,active:false,deadline:null,soldIds:[],
      hostTeam:[],guestTeam:[],hostMoney:modeValue==="11"?200:100,
      guestMoney:modeValue==="11"?200:100,auctionRound:0,slotIndex:0,hidden:modeValue==="hidden",
      lastMessage:"الغرفة اتعملت — مستني صاحبك يدخل.",
      chat:[],
      voice:{offer:null,answer:null,hostCandidates:[],guestCandidates:[]}
    };
  }

  async function saveState(){
    if(!configured()||!onlineRoomCode||!onlineState)return false;
    onlineState.version=(onlineState.version||0)+1;
    const r=await agUpdateOnlineRoom(onlineRoomCode,onlineState);
    if(!r.ok){console.error(r.error);log?.("ai","❌ "+(r.error?.message||"فشل حفظ الغرفة"));return false;}
    onlineVersion=onlineState.version; return true;
  }

  async function mutateRoomOnCode(code, mutator, options={}){
    if(!configured()||!code)return {ok:false,error:{message:"الغرفة غير متاحة"}};
    for(let attempt=0;attempt<4;attempt++){
      const fresh=await agGetOnlineRoom(code);
      if(!fresh.ok||!fresh.data?.state)return {ok:false,error:fresh.error||{message:"تعذر قراءة حالة الغرفة"}};
      const base=fresh.data.state||{};
      const expected=Number(base.version||0);
      const next=JSON.parse(JSON.stringify(base));
      try{await mutator(next,fresh.data);}catch(e){return {ok:false,error:{message:e.message}};}
      next.version=expected+1;
      const r=await agUpdateOnlineRoom(code,next,options.extra||{},expected);
      if(r.ok)return r;
      if(!r.conflict)return r;
      await new Promise(res=>setTimeout(res,120+attempt*150));
    }
    return {ok:false,error:{message:"الغرفة اتغيرت أثناء الدخول. جرّب دخول الغرفة مرة ثانية."}};
  }

  async function mutateRoom(mutator, options={}){
    if(!configured()||!onlineRoomCode)return {ok:false,error:{message:"الغرفة غير متاحة"}};
    for(let attempt=0;attempt<3;attempt++){
      const fresh=await agGetOnlineRoom(onlineRoomCode);
      if(!fresh.ok||!fresh.data?.state) return {ok:false,error:fresh.error||{message:"تعذر قراءة حالة الغرفة"}};
      const base=fresh.data.state||{};
      const expected=Number(base.version||0);
      const next=JSON.parse(JSON.stringify(base));
      try{ await mutator(next, fresh.data); }catch(e){ return {ok:false,error:{message:e.message}}; }
      next.version=expected+1;
      const r=await agUpdateOnlineRoom(onlineRoomCode,next, options.extra||{}, expected);
      if(r.ok){ onlineState=r.data?.state||next; onlineVersion=Number(onlineState.version||next.version); applyOnlineState(); return r; }
      if(!r.conflict) return r;
      await new Promise(res=>setTimeout(res,120+attempt*120));
    }
    return {ok:false,error:{message:"الغرفة اتغيرت بسرعة. حاول المرة دي تاني."}};
  }

  function escapeChat(v){return String(v||"").replace(/[&<>\"]/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;"}[m]));}

  function playerById(id){return(window.players||[]).find(p=>String(p.id)===String(id));}
  function teamForMe(s){return s.host_id===onlinePlayerId?(s.hostTeam||[]):(s.guestTeam||[]);}
  function teamForOpp(s){return s.host_id===onlinePlayerId?(s.guestTeam||[]):(s.hostTeam||[]);}
  function myTeam(){return teamForMe(onlineState);}

  function showLobby(s){
    document.getElementById("home")?.classList.add("hidden");
    document.getElementById("lobby")?.classList.remove("hidden");
    const rc=document.getElementById("roomCodeView"); if(rc)rc.textContent=s.room_code;
    const me=s.host_id===onlinePlayerId;
    const members=[];
    if(s.host_id)members.push(`<div class="member"><b>${s.host_name||"صاحب الغرفة"}</b><br><span class="success">● متصل</span></div>`);
    if(s.guest_id)members.push(`<div class="member"><b>${s.guest_name||"الضيف"}</b><br><span class="success">● متصل</span></div>`);
    else members.push(`<div class="member"><b>في انتظار اللاعب الثاني...</b><br><span class="muted">شارك كود الغرفة مع صاحبك</span></div>`);
    const rm=document.getElementById("roomMembers");if(rm)rm.innerHTML=members.join("");
    const rs=document.getElementById("roomState");if(rs){
      const vis=s.visibility==="public"?"🌍 عامة — تظهر في قائمة الغرف":"🔒 خاصة — الدخول بالكود";
      rs.textContent=vis+" • "+(s.guest_id?(me?"اللاعب الثاني دخل.":"مستني صاحب الغرفة يبدأ."):"مستني اللاعب الثاني يدخل...");
    }
    const btn=document.querySelector('#lobby button[onclick="beginRoom()"]');
    if(btn){btn.disabled=!me||!s.guest_id;btn.textContent=!s.guest_id?"مستني اللاعب الثاني...":(me?"ابدأ المزاد":"مستني صاحب الغرفة...");btn.style.opacity=btn.disabled?".55":"1";}
    renderSocialPanel(s);
  }

  function subscribe(code){
    agSubscribeRoom(code,payload=>{
      if(payload?.state){
        onlineState=payload.state;onlineVersion=onlineState.version||0;applyOnlineState();
      }
    });
  }

  window.selectedRoomVisibility="private";
  window.selectRoomVisibility=function(v){
    window.selectedRoomVisibility=v==="public"?"public":"private";
    const a=document.getElementById("privateRoomBtn"),b=document.getElementById("publicRoomBtn");
    if(a){a.className=window.selectedRoomVisibility==="private"?"primary full":"dark full";}
    if(b){b.className=window.selectedRoomVisibility==="public"?"primary full":"dark full";}
    const msg=document.getElementById("roomSetupMsg");
    if(msg)msg.textContent=window.selectedRoomVisibility==="public"?"الغرفة العامة هتظهر في قائمة الغرف لأي لاعب." : "الغرفة الخاصة لن تظهر في القائمة — الدخول بالكود فقط.";
  };

  function roomModeLabel(m){return m==="11"?"مزاد 11 لاعب • 200 مليون":m==="hidden"?"مزاد اللاعب الخفي • 100 مليون":"مزاد 5 لاعيبة • 100 مليون";}
  window.refreshPublicRooms=async function(){
    const box=document.getElementById("publicRooms"); if(!box)return;
    box.innerHTML='<div class="muted">جاري تحميل الغرف العامة...</div>';
    const r=await agListPublicRooms();
    if(!r.ok){box.innerHTML='<div class="muted">تعذر تحميل الغرف: '+(r.error?.message||"خطأ في الاتصال")+'</div>';return;}
    if(!r.data.length){box.innerHTML='<div class="muted">لا توجد غرف عامة مفتوحة حاليًا.</div>';return;}
    box.innerHTML=r.data.map(x=>{
      const s=x.state||{},code=String(x.code||s.room_code||"");
      const mode=s.mode||"5";
      const host=(s.host_name||"لاعب").replace(/[<>]/g,"");
      return `<div class="public-room"><div class="room-info"><div class="room-title">${host} <span class="room-badge">متاحة</span></div><div class="room-meta">${roomModeLabel(mode)} • لاعبان فقط • كود ${code}</div></div><button class="primary" onclick="joinPublicRoom('${code}','${mode}')">دخول 🎮</button></div>`;
    }).join("");
  };

  window.joinPublicRoom=async function(code,modeValue){
    mode=String(modeValue||"5"); selectedAuctionType=mode;
    const input=document.getElementById("roomCodeInput"); if(input)input.value=code;
    if(typeof window.joinRoom==="function") await window.joinRoom();
  };

  async function createRoomOnline(){
    if(!configured()){alert("بيانات Supabase غير جاهزة.");return;}
    setupIdentity();
    const code=String(Math.floor(100000+Math.random()*900000));
    window.selectedRoomVisibility=window.selectedRoomVisibility||"private";
    const state=roomStateBase(code,window.mode||"5");
    state.visibility=window.selectedRoomVisibility;
    state.lastMessage=state.visibility==="public"?"الغرفة العامة اتعملت — أي لاعب يقدر يلاقيها ويدخلها.":"الغرفة الخاصة اتعملت — الدخول بالكود فقط.";
    const r=await agCreateOnlineRoom(code,state,onlinePlayerId);
    if(!r.ok){alert("فشل إنشاء الغرفة: "+(r.error?.message||"خطأ في الاتصال"));return;}
    onlineRoomCode=code;onlineIsHost=true;onlineState=r.data?.state||state;
    subscribe(code);showLobby(onlineState);
  }

  async function joinRoomOnline(){
    if(!configured()){alert("بيانات Supabase غير جاهزة.");return;}
    setupIdentity();
    const code=(document.getElementById("roomCodeInput")?.value||"").trim();
    if(!/^\d{6}$/.test(code)){alert("اكتب كود غرفة من 6 أرقام");return;}
    const r=await agGetOnlineRoom(code);
    if(!r.ok){alert("خطأ في الاتصال: "+(r.error?.message||""));return;}
    if(!r.data){alert("الغرفة غير موجودة.");return;}
    if(r.data.guest_id&&r.data.guest_id!==onlinePlayerId){alert("الغرفة مكتملة — لاعبان فقط.");return;}
    const s=r.data.state||{};
    if(s.status==="playing"||s.phase==="auction"){alert("المزاد بدأ بالفعل.");return;}
    if(s.guest_id&&s.guest_id!==onlinePlayerId){alert("الغرفة مكتملة — لاعبان فقط.");return;}
    onlineRoomCode=code;onlineIsHost=false;
    const upd=await mutateRoomOnCode(code, async next=>{
      if(next.status==="playing"||next.phase==="auction") throw new Error("المزاد بدأ بالفعل.");
      if(next.guest_id&&next.guest_id!==onlinePlayerId) throw new Error("الغرفة مكتملة — لاعبان فقط.");
      next.guest_id=onlinePlayerId;next.guest_name=onlinePlayerName;next.status="ready";
      next.phase="lobby";next.lastMessage=onlinePlayerName+" دخل الغرفة.";
    });
    if(!upd.ok){onlineRoomCode=null;onlineIsHost=false;alert("فشل دخول الغرفة: "+(upd.error?.message||""));return;}
    onlineState=upd.data?.state||s;
    subscribe(code);showLobby(onlineState);
  }

  async function startOnlineAuction(){
    if(!onlineRoomCode||!onlineIsHost){alert("صاحب الغرفة فقط يبدأ المزاد.");return false;}
    const list=window.players||[];
    if(!list.length){alert("قاعدة اللاعبين غير محملة.");return false;}
    const r=await mutateRoom(s=>{
      if(s.phase!=="lobby" || s.status==="cancelled") throw new Error("الغرفة ليست جاهزة للبدء.");
      if(!s.guest_id) throw new Error("مستني اللاعب الثاني يدخل.");
      const p=pickAuctionPlayer(list,s.soldIds||[],s.mode||"5",0);
      if(!p) throw new Error("مفيش لاعبين متاحين للمزاد.");
      s.status="playing";s.phase="auction";s.currentPlayerId=p.id;
      s.currentBid=1;s.lastBidderId=null;s.turn=s.host_id;s.active=true;
      s.deadline=Date.now()+20000;s.auctionRound=1;s.slotIndex=0;s.passRequest=null;s.claimRequest=null;
      s.currentRole=p.pos;s.lastMessage="بدأ المزاد 🔨 — "+auctionRoleLabel(p.pos);
    });
    if(!r.ok){alert("تعذر بدء المزاد: "+(r.error?.message||"خطأ في الاتصال"));return false;}
    onlineState=r.data?.state||onlineState;
    onlineVersion=Number(onlineState?.version||0);
    applyOnlineState();
    return true;
  }

  function renderPitchFromTeam(teamList){
    const slots={GK:["gk"],DEF:["d1","d2","d3","d4"],MID:["m1","m2","m3","m4"],FWD:["f1","f2"]};
    const all=["gk","d1","d2","d3","d4","m1","m2","m3","m4","f1","f2"];
    all.forEach(id=>{const el=document.getElementById(id);if(el)el.innerHTML="";});
    const taken={GK:0,DEF:0,MID:0,FWD:0};
    (teamList||[]).slice(0,11).forEach(x=>{
      const arr=slots[x.pos]||slots.FWD, idx=taken[x.pos]||0;
      const id=arr[Math.min(idx,arr.length-1)]; taken[x.pos]=(taken[x.pos]||0)+1;
      const el=document.getElementById(id); if(!el)return;
      const img=x.img?'<img src="'+x.img+'" onerror="this.style.display=\'none\'">':'⚽';
      el.innerHTML='<div class="picon">'+img+'</div><b>'+x.name+'</b>';
    });
  }

  function renderOnlineTeams(){
    const mine=myTeam(),opp=teamForOpp(onlineState);
    const teamBox=document.getElementById("team");
    if(teamBox)teamBox.innerHTML=mine.map(x=>`<div class="member">${x.img?`<img src="${x.img}" onerror="this.style.display='none'>`:"⚽"}<br><b>${x.name}</b><br><span class="muted">${x.cost||0}M</span></div>`).join("");
    const oppBox=document.getElementById("opponentTeam");
    if(oppBox)oppBox.innerHTML=opp.map(x=>`<div class="member">${x.img?`<img src="${x.img}" onerror="this.style.display='none'>`:"⚽"}<br><b>${x.name}</b><br><span class="muted">${x.pos||""} • ${x.rate||""}</span></div>`).join("");
    const m=document.getElementById("money");
    if(m)m.textContent=(onlineState.host_id===onlinePlayerId?(onlineState.hostMoney??onlineState.budget):(onlineState.guestMoney??onlineState.budget))+"M";
    renderPitchFromTeam(mine);
  }

  function renderOnlineAuction(){
    try{
      const p=playerById(onlineState.currentPlayerId);
      if(!p){
        const card=document.getElementById("auctionCard");
        if(card)card.innerHTML='<div class="notice">⏳ جاري تحميل اللاعب...</div>';
        return;
      }
      window.current=p;window.currentBid=onlineState.currentBid||1;window.active=!!onlineState.active;
      window.lastBidder=onlineState.lastBidderId===onlinePlayerId?"أنت":onlineState.lastBidderId?
        (onlineState.lastBidderId===onlineState.host_id?onlineState.host_name:onlineState.guest_name):null;
      const card=document.getElementById("auctionCard");
      if(card&&typeof cardHTML==="function")card.innerHTML=cardHTML(p,true);
      const hiddenControls=document.getElementById("hiddenControls");
      const hintsBox=document.getElementById("hints");
      if(hiddenControls)hiddenControls.classList.toggle("hidden",!onlineState.hidden);
      if(onlineState.hidden){
        const nm=document.querySelector("#auctionCard .pc-name");if(nm)nm.textContent="اللاعب الخفي";
        const rt=document.querySelector("#auctionCard .rating");if(rt)rt.textContent="?";
        const po=document.querySelector("#auctionCard .position");if(po)po.textContent="???";
        const im=document.querySelector("#auctionCard .pc-photo img");if(im)im.style.display="none";
        const st=document.querySelector("#auctionCard .pc-stats");if(st)st.innerHTML="<span>؟<small>PAC</small></span><span>؟<small>SHO</small></span><span>؟<small>PAS</small></span><span>؟<small>DRI</small></span><span>؟<small>DEF</small></span><span>؟<small>PHY</small></span>";
        const rk="ag_hidden_round_"+String(onlineState.auctionRound||0);
        if(hintsBox&&sessionStorage.getItem("ag_hidden_last_round")!==rk){hintsBox.innerHTML="";sessionStorage.setItem("ag_hidden_last_round",rk);}
      } else if(hintsBox){hintsBox.innerHTML="";}
      const price=document.getElementById("price");if(price)price.textContent=(onlineState.currentBid||1)+"M";
      const turn=document.getElementById("turn");if(turn)turn.textContent=onlineState.turn===onlinePlayerId&&onlineState.active?"دورك — زوّد الآن":(onlineState.active?"دور الخصم...":"انتهى المزاد");
      const myTurn=String(onlineState.turn)===String(onlinePlayerId)&&!!onlineState.active;
      const b=document.getElementById("bid");if(b){b.value=Math.max((onlineState.currentBid||1)+1,2);b.disabled=!myTurn;}
      const cb=document.querySelector('[onclick="claim()"]');if(cb)cb.disabled=!(onlineState.active&&onlineState.lastBidderId===onlinePlayerId);
      const pb=document.querySelector('[onclick="pass()"]');if(pb)pb.disabled=!onlineState.active;
      renderSocialPanel(onlineState);
    }catch(e){
      console.error("renderOnlineAuction",e);
      const feed=document.getElementById("feed");if(feed)feed.innerHTML='<div class="msg ai">⚠️ حصل خطأ في عرض المزاد، جاري إعادة المزامنة...</div>'+feed.innerHTML;
    }
  }

  function applyOnlineState(){
    try{
      if(!onlineState)return;
      if(onlineState.status==="cancelled" || onlineState.phase==="cancelled"){
        alert("🚪 صاحب الغرفة خرج — تم إغلاق الغرفة.");
        if(typeof window.exitRoom==="function") window.exitRoom();
        return;
      }
      renderSocialPanel(onlineState);
      if(onlineIsHost && onlineState.phase==="auction" && (onlineState.passRequest||onlineState.claimRequest)){
        const req = onlineState.claimRequest ? "claim" : "pass";
        onlineResolve(req);
        return;
      }
      if(onlineState.phase==="lobby"){showLobby(onlineState);return;}
      if(onlineState.phase!=="auction" && onlineState.phase!=="finished"){
        document.getElementById("home")?.classList.remove("hidden");
        document.getElementById("lobby")?.classList.add("hidden");
        document.getElementById("game")?.classList.add("hidden");
        return;
      }
      document.getElementById("home")?.classList.add("hidden");
      document.getElementById("lobby")?.classList.add("hidden");
      document.getElementById("game")?.classList.remove("hidden");
      document.getElementById("teamPanel")?.classList.remove("hidden");
      document.getElementById("matchPanel")?.classList.remove("hidden");
      renderOnlineTeams();renderOnlineAuction();
      if(onlineTimer)clearInterval(onlineTimer);
      if(onlineState.active&&onlineState.deadline){
        onlineTimer=setInterval(()=>{
          const left=Math.max(0,Math.ceil((onlineState.deadline-Date.now())/1000));
          const t=document.getElementById("timer");if(t)t.textContent=left;
          if(left<=0){clearInterval(onlineTimer);if(onlineIsHost)onlineResolve("timeout");}
        },250);
      }
      if(onlineState.lastMessage&&typeof log==="function"){
        const key="ag_last_msg_"+onlineState.version;
        if(!sessionStorage.getItem(key)){sessionStorage.setItem(key,"1");log("info",onlineState.lastMessage);}
      }
      applyVoiceState(onlineState);
    }catch(e){
      console.error("applyOnlineState",e);
      document.getElementById("home")?.classList.remove("hidden");
      document.getElementById("lobby")?.classList.add("hidden");
      document.getElementById("game")?.classList.add("hidden");
    }
  }

  let onlineBidBusy=false;
  async function onlineBid(value){
    value=parseInt(value);
    if(onlineBidBusy||!onlineRoomCode||!Number.isFinite(value))return;
    onlineBidBusy=true;
    const r=await mutateRoom(async s=>{
      if(!s.active||s.phase!=="auction")throw new Error("المزاد غير نشط.");
      if(String(s.turn)!==String(onlinePlayerId))throw new Error("مش دورك دلوقتي — استنى الخصم.");
      const money=s.host_id===onlinePlayerId?(s.hostMoney??s.budget):(s.guestMoney??s.budget);
      const currentPrice=Number(s.currentBid||1);
      if(value<=currentPrice)throw new Error("لازم تزيد عن "+currentPrice+"M");
      if(value>Number(money||0))throw new Error("ميزانيتك لا تكفي.");
      s.currentBid=value;
      s.lastBidderId=onlinePlayerId;
      s.turn=onlinePlayerId===s.host_id?s.guest_id:s.host_id;
      s.lastMessage=onlinePlayerName+" زاد إلى "+value+"M 🔥";
      s.bidNonce=(Number(s.bidNonce)||0)+1;
    });
    onlineBidBusy=false;
    if(!r.ok)log?.("ai","❌ "+(r.error?.message||"فشلت المزايدة، جرّب مرة ثانية."));
    else log?.("you","🔥 تم تسجيل مزايدتك: "+value+"M");
  }

  // One bid API for both modes. The old version overwrote the local-AI bid handler
  // with the online handler, which is why pressing + in AI mode did nothing.
  const localBidHandler=window.myBid;
  window.myBid=async function(){
    const input=document.getElementById("bid");
    const value=parseInt(input?.value);
    if(onlineRoomCode && onlineState){
      await onlineBid(value);
    }else if(typeof localBidHandler==="function"){
      localBidHandler(value);
    }
  };
  window.add=function(n){
    const b=document.getElementById("bid");
    if(!b)return;
    const base=onlineRoomCode&&onlineState ? Number(onlineState.currentBid||1) : Number(currentBid||1);
    b.value=base+n;
    window.myBid();
  };

  async function onlineResolve(reason){
    if(!onlineRoomCode)return;
    const r=await mutateRoom(s=>{
      if(s.phase!=="auction")throw new Error("المزاد انتهى بالفعل.");
      const now=Date.now();
      const timedOut=reason==="timeout" && s.deadline && now < Number(s.deadline);
      if(timedOut)return;
      if(!s.active)return;
      const p=playerById(s.currentPlayerId);if(!p)throw new Error("اللاعب الحالي غير موجود.");
      const winner=s.lastBidderId;
      // الحسم مسموح فقط لأعلى مزايد، وليس لمن عليه الدور فقط.
      if(reason==="claim" && String(winner)!==String(onlinePlayerId))
        throw new Error("أنت مش أعلى مزايد حاليًا.");
      // الانسحاب يخرجك من الجولة فورًا حتى لو كان دور الخصم. لو الخصم هو الأعلى، يفوز مباشرة.
      const shouldFinish=!!winner && (reason==="claim" || reason==="pass" || reason==="timeout");
      s.active=false;s.deadline=null;s.turn=null;
      if(shouldFinish){
        const hostWon=winner===s.host_id;
        const key=hostWon?"hostTeam":"guestTeam", moneyKey=hostWon?"hostMoney":"guestMoney";
        const money=Number(s[moneyKey]??s.budget??100);
        s[key]=Array.isArray(s[key])?s[key]:[];
        s[key].push({...p,cost:Number(s.currentBid||1)});
        s[moneyKey]=Math.max(0,money-Number(s.currentBid||1));
        s.soldIds=Array.isArray(s.soldIds)?s.soldIds:[];
        if(!s.soldIds.includes(p.id))s.soldIds.push(p.id);
        s.lastMessage=(hostWon?s.host_name:s.guest_name)+" كسب "+p.name+" بـ "+s.currentBid+"M 🏆";
      }else{
        s.soldIds=Array.isArray(s.soldIds)?s.soldIds:[];
        if(!s.soldIds.includes(p.id))s.soldIds.push(p.id);
        s.lastMessage="انتهى الوقت بدون مزايدة.";
      }
      const hostDone=(s.hostTeam||[]).length>=Number(s.maxPlayers||5);
      const guestDone=(s.guestTeam||[]).length>=Number(s.maxPlayers||5);
      if(hostDone||guestDone){
        s.phase="finished";s.status="finished";s.turn=null;return;
      }
      const nextRound=Number(s.slotIndex||0)+1;
      const seq=auctionRoleSequence(s.mode||"5");
      if(nextRound>=seq.length){s.phase="finished";s.status="finished";s.turn=null;s.active=false;return;}
      const next=pickAuctionPlayer(window.players||[],s.soldIds||[],s.mode||"5",nextRound);
      if(!next){s.phase="finished";s.status="finished";s.turn=null;s.active=false;return;}
      s.slotIndex=nextRound;s.currentPlayerId=next.id;s.currentBid=1;s.lastBidderId=null;
      s.turn=(Number(s.auctionRound||0)%2===0)?s.guest_id:s.host_id;
      s.active=true;s.deadline=Date.now()+20000;s.auctionRound=Number(s.auctionRound||0)+1;
      s.currentRole=next.pos;s.passRequest=null;s.claimRequest=null;
      s.lastMessage="الجولة التالية 🔨 — "+auctionRoleLabel(next.pos);
    });
    if(!r.ok && r.error?.message)log?.("ai","❌ "+r.error.message);
  }

  window.claim=async function(){
    const fresh=await agGetOnlineRoom(onlineRoomCode);
    const s=fresh.data?.state;
    if(!s||!s.active||String(s.lastBidderId)!==String(onlinePlayerId)){
      log?.("ai","⚠️ لازم تكون أعلى مزايد عشان تحسم الصفقة.");return;
    }
    await onlineResolve("claim");
  };
  window.pass=async function(){
    const fresh=await agGetOnlineRoom(onlineRoomCode);
    const s=fresh.data?.state;
    if(!s||!s.active){log?.("ai","⚠️ الجولة انتهت بالفعل.");return;}
    await onlineResolve("pass");
  };

  window.hint=async function(){
    if(!onlineState?.hidden||!onlineState.currentPlayerId)return;
    const p=playerById(onlineState.currentPlayerId);
    const hints=document.getElementById("hints");
    if(!p||!hints)return;
    const roundKey="ag_online_hidden_hint_count_"+String(onlineState.auctionRound||0);
    let count=Number(sessionStorage.getItem(roundKey)||0);
    const list=[
      "المركز: "+(p.pos==="GK"?"حارس مرمى":p.pos==="DEF"?"مدافع":p.pos==="MID"?"لاعب وسط":"مهاجم"),
      "الجنسية: "+(p.flag||"غير معروفة"),
      "الفئة: "+(p.rate>=95?"أسطورة عالمية 🔥":p.rate>=90?"نجم عالمي ⭐":p.rate>=85?"لاعب قوي 💪":"لاعب متوسط 🎯"),
      "التقييم التقريبي: "+(p.rate>=95?"95–99":p.rate>=90?"90–94":p.rate>=85?"85–89":"أقل من 85")
    ];
    if(count>=list.length){log?.("ai","🔎 كل التلميحات المتاحة اتعرضت بالفعل.");return;}
    hints.insertAdjacentHTML("beforeend",`<div class='notice' style='margin-top:6px'>🔎 ${list[count]}</div>`);
    sessionStorage.setItem(roundKey,String(count+1));
  };

  window.createRoom=async function(){if(!getUser()){showAuth();return;}await createRoomOnline();};
  window.joinRoom=async function(){if(!getUser()){showAuth();return;}await joinRoomOnline();};
  window.openRoom=function(code,host){onlineRoomCode=String(code);onlineIsHost=!!host;setupIdentity();};
  window.beginRoom=async function(){
    if(!onlineIsHost){alert("صاحب الغرفة فقط يبدأ المزاد.");return;}
    if(!onlineState?.guest_id){alert("مستني اللاعب الثاني يدخل.");return;}
    const ok=await startOnlineAuction();
    if(ok) document.getElementById("lobby")?.classList.add("hidden");
  };
  // Route the generic start button safely: online rooms use the online starter;
  // AI mode always uses the local AI starter. The old version overwrote the AI starter
  // with this function, so pressing Start left the game area completely blank.
  window.startAuction=async function(){
    if(onlineRoomCode){
      if(!onlineIsHost){alert("مستني صاحب الغرفة يبدأ المزاد.");return;}
      await startOnlineAuction();return;
    }
    if(typeof window.startLocalAIAuction==="function"){ window.startLocalAIAuction(); return; }
    alert("تعذر بدء المزاد.");
  };

  let voicePC=null, voiceStream=null, voiceStarted=false, voiceRemote=null;
  const voiceSeen={host:new Set(),guest:new Set()};

  function socialHtml(){
    return `<div id="agSocialGlobal" class="panel" style="margin:10px 0;direction:rtl">
      <h3>💬 شات الغرفة</h3>
      <div id="agChat" style="height:150px;overflow:auto;background:#08101d;border:1px solid #24344d;border-radius:12px;padding:8px"></div>
      <div class="row" style="margin-top:7px"><input id="agChatInput" class="input" placeholder="اكتب رسالة..." maxlength="240"><button class="primary" onclick="sendRoomChat()">إرسال</button></div>
      <div class="row" style="margin-top:7px"><button id="agVoiceBtn" class="blue" onclick="toggleRoomVoice()">🎙️ تشغيل المحادثة الصوتية</button><button class="dark" onclick="stopRoomVoice()">🔇 إيقاف الصوت</button></div>
      <div id="agVoiceStatus" class="muted" style="margin-top:6px">الصوت متوقف</div>
      <audio id="agRemoteAudio" autoplay playsinline></audio>
    </div>`;
  }
  function ensureSocialPanel(){
    if(!document.getElementById("agSocialGlobal")){
      const d=document.createElement("div");d.innerHTML=socialHtml();
      document.body.appendChild(d.firstElementChild);
    }
  }
  function renderSocialPanel(s){
    ensureSocialPanel();
    const panel=document.getElementById("agSocialGlobal");
    if(!panel)return;
    panel.classList.toggle("hidden",!s||!onlineRoomCode);
    const box=document.getElementById("agChat");
    if(box){
      const msgs=Array.isArray(s?.chat)?s.chat:[];
      box.innerHTML=msgs.map(m=>`<div style="margin:4px 0"><b>${escapeChat(m.name||"لاعب")}:</b> ${escapeChat(m.text)}</div>`).join("")||'<div class="muted">مفيش رسائل لسه.</div>';
      box.scrollTop=box.scrollHeight;
    }
    const status=document.getElementById("agVoiceStatus");if(status)status.textContent=voiceStarted?"🟢 المحادثة الصوتية شغالة":"الصوت متوقف";
  }
  window.sendRoomChat=async function(){
    const input=document.getElementById("agChatInput"),text=(input?.value||"").trim();if(!text||!onlineRoomCode)return;
    input.value="";
    const r=await mutateRoom(s=>{s.chat=Array.isArray(s.chat)?s.chat:[];s.chat.push({id:Date.now()+"-"+Math.random(),name:onlinePlayerName,text,at:Date.now()});if(s.chat.length>100)s.chat=s.chat.slice(-100);});
    if(!r.ok)log?.("ai","❌ تعذر إرسال الرسالة.");
  };

  async function voicePatch(mutator){return mutateRoom(async s=>{s.voice=s.voice||{offer:null,answer:null,hostCandidates:[],guestCandidates:[]};await mutator(s.voice);});}
  async function addVoiceCandidate(c){
    if(!c)return;
    const side=onlineIsHost?"hostCandidates":"guestCandidates";
    await voicePatch(v=>{v[side]=Array.isArray(v[side])?v[side]:[];const key=JSON.stringify(c);if(!v[side].some(x=>JSON.stringify(x)===key))v[side].push(c);});
  }
  async function createVoiceConnection(){
    if(voicePC)return voicePC;
    if(!navigator.mediaDevices?.getUserMedia || !window.RTCPeerConnection)throw new Error("المتصفح لا يدعم المحادثة الصوتية هنا.");
    voiceStream=await navigator.mediaDevices.getUserMedia({audio:true,video:false});
    voicePC=new RTCPeerConnection({iceServers:[{urls:"stun:stun.l.google.com:19302"}]});
    voiceRemote=document.getElementById("agRemoteAudio");
    voicePC.ontrack=e=>{if(voiceRemote&&e.streams[0]){voiceRemote.srcObject=e.streams[0];voiceRemote.play?.().catch(()=>{});}};
    voicePC.onicecandidate=e=>{if(e.candidate)addVoiceCandidate(e.candidate.toJSON?e.candidate.toJSON():e.candidate);};
    voiceStream.getTracks().forEach(t=>voicePC.addTrack(t,voiceStream));
    return voicePC;
  }
  async function applyVoiceState(s){
    if(!s?.voice)return;
    const v=s.voice;
    try{
      // The host can start the call; the guest automatically prepares the microphone
      // when an offer arrives, so both players do not have to press the voice button.
      if(!onlineIsHost && v.offer && !voicePC){
        await createVoiceConnection();
        voiceStarted=true;
        renderSocialPanel(s);
      }
      if(!voicePC)return;
      if(!onlineIsHost && v.offer && voicePC.signalingState==="stable" && !voicePC.__offerSet){
        await voicePC.setRemoteDescription(v.offer);voicePC.__offerSet=true;
        const ans=await voicePC.createAnswer();await voicePC.setLocalDescription(ans);
        await voicePatch(x=>{x.answer={type:ans.type,sdp:ans.sdp};});
      }
      if(onlineIsHost && v.answer && voicePC.signalingState!=="closed" && !voicePC.__answerSet){
        await voicePC.setRemoteDescription(v.answer);voicePC.__answerSet=true;
      }
      const arr=onlineIsHost?(v.guestCandidates||[]):(v.hostCandidates||[]);
      const seen=onlineIsHost?voiceSeen.guest:voiceSeen.host;
      for(const c of arr){const key=JSON.stringify(c);if(seen.has(key))continue;seen.add(key);try{await voicePC.addIceCandidate(c);}catch(e){}}
    }catch(e){console.warn("voice signaling",e);}
  }
  window.toggleRoomVoice=async function(){
    try{
      if(voiceStarted){stopRoomVoice();return;}
      if(!onlineState?.guest_id){alert("المحادثة الصوتية تحتاج لاعبًا ثانيًا في الغرفة.");return;}
      await createVoiceConnection();voiceStarted=true;renderSocialPanel(onlineState);
      if(onlineIsHost){const offer=await voicePC.createOffer();await voicePC.setLocalDescription(offer);await voicePatch(v=>{v.offer={type:offer.type,sdp:offer.sdp};v.answer=null;v.hostCandidates=[];v.guestCandidates=[];});}
      else {const latest=await agGetOnlineRoom(onlineRoomCode);if(latest.data?.state)await applyVoiceState(latest.data.state);}
    }catch(e){stopRoomVoice();alert("تعذر تشغيل الميكروفون: "+e.message);}
  };
  window.stopRoomVoice=function(){
    voiceStarted=false;voiceSeen.host.clear();voiceSeen.guest.clear();
    try{voicePC?.close();}catch(e){};voicePC=null;
    try{voiceStream?.getTracks().forEach(t=>t.stop());}catch(e){};voiceStream=null;
    const a=document.getElementById("agRemoteAudio");if(a)a.srcObject=null;renderSocialPanel(onlineState||{});
  };
  ensureSocialPanel();

  window.AhmedGamesOnline = window.AhmedGamesOnline || {};
  window.AhmedGamesOnline.leaveRoom = async function(){
    const code=onlineRoomCode;
    const wasHost=onlineIsHost;
    const state=onlineState;
    // Stop polling immediately so the user can leave even if the server is unavailable.
    if(agPollTimer) clearInterval(agPollTimer);
    agPollTimer=null;
    if(code && configured()){
      try{
        if(wasHost){
          const closed=Object.assign({}, state||{}, {status:"cancelled",phase:"cancelled",active:false,lastMessage:"صاحب الغرفة خرج من الغرفة."});
          await agUpdateOnlineRoom(code,closed,{status:"cancelled"});
        }else if(state){
          const next=Object.assign({},state,{guest_id:null,guest_name:null,status:"waiting",phase:"lobby",lastMessage:onlinePlayerName+" خرج من الغرفة.",version:(state.version||0)+1});
          await agUpdateOnlineRoom(code,next,{guest_id:null,status:"waiting"});
        }
      }catch(e){ console.warn("leave room update failed",e); }
    }
    stopRoomVoice();
    onlineRoomCode=null;onlineState=null;onlineIsHost=false;onlineVersion=0;
    document.getElementById("agSocialGlobal")?.classList.add("hidden");
    document.getElementById("lobby")?.classList.add("hidden");
    document.getElementById("game")?.classList.add("hidden");
    document.getElementById("teamPanel")?.classList.add("hidden");
    document.getElementById("matchPanel")?.classList.add("hidden");
    document.getElementById("home")?.classList.remove("hidden");
  };

  // Keep status visible and verify connectivity.
  async function setStatus(){
    const dot=document.getElementById("ag-online-dot"),text=document.getElementById("ag-online-text");
    if(!dot||!text)return;
    if(!configured()){dot.style.background="#f5a623";text.textContent="🟡 أونلاين: إعداد Supabase غير مكتمل";return;}
    const test=await agGetOnlineRoom("000000");
    if(test.ok || test.error?.message?.includes("No rows") || test.error?.details?.code==="PGRST116"){
      dot.style.background="#22c55e";text.textContent="🟢 أونلاين: Supabase متصل";
    }else{
      dot.style.background="#ef4444";text.textContent="🔴 أونلاين: خطأ اتصال";
    }
  }
  setTimeout(setStatus,500);
  window.AhmedGamesOnline=Object.assign(window.AhmedGamesOnline||{}, {getState:()=>onlineState,getRoom:()=>onlineRoomCode});
})();
