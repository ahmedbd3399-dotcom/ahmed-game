
/* Ahmed Games LIVE - direct Supabase REST connector (works from a local HTML file) */
window.AHMED_GAMES_CONFIG = {
  url: "https://jkccqbaqurkhgbttrdks.supabase.co",
  publishableKey: "sb_publishable_CLQp4K0eb3aVP-15m5JTBA_N0w9O9uP"
};

let agRealtimeChannel = null;
let agPollTimer = null;

function agHeaders(extra={}) {
  return Object.assign({
    "apikey": window.AHMED_GAMES_CONFIG.publishableKey,
    "Authorization": "Bearer " + (window.AHMED_GAMES_AUTH_TOKEN || window.AHMED_GAMES_CONFIG.publishableKey),
    "Content-Type": "application/json"
  }, extra);
}

function agApiUrl(path) {
  return window.AHMED_GAMES_CONFIG.url.replace(/\/+$/,"") + "/rest/v1/" + path;
}

window.agIsConfigured = function agIsConfigured() {
  const c=window.AHMED_GAMES_CONFIG;
  return !!(c && c.url && c.url.startsWith("https://") &&
            c.publishableKey && c.publishableKey.startsWith("sb_publishable_"));
}

async function agCreateOnlineRoom(roomCode, roomData, hostId) {
  if(!agIsConfigured()) return {ok:false,reason:"not_configured"};
  try {
    const r=await fetch(agApiUrl("rooms"),{
      method:"POST", headers:agHeaders({"Prefer":"return=representation"}),
      body:JSON.stringify({
        code:String(roomCode), host_id:hostId, status:"waiting", state:roomData
      })
    });
    const data=await r.json().catch(()=>null);
    if(!r.ok) return {ok:false,error:{message:data?.message||data?.hint||("HTTP "+r.status),details:data}};
    return {ok:true,data:data?.[0]||data};
  } catch(e) { return {ok:false,error:{message:e.message}}; }
}

async function agGetOnlineRoom(roomCode) {
  if(!agIsConfigured()) return {ok:false,reason:"not_configured"};
  try {
    const r=await fetch(agApiUrl("rooms?code=eq."+encodeURIComponent(roomCode)+"&select=*"),{
      headers:agHeaders()
    });
    const data=await r.json().catch(()=>null);
    if(!r.ok) return {ok:false,error:{message:data?.message||data?.hint||("HTTP "+r.status),details:data}};
    return {ok:true,data:data?.[0]||null};
  } catch(e) { return {ok:false,error:{message:e.message}}; }
}

async function agUpdateOnlineRoom(roomCode, roomData, extra={}) {
  if(!agIsConfigured()) return {ok:false,reason:"not_configured"};
  try {
    const body=Object.assign({state:roomData},extra);
    const r=await fetch(agApiUrl("rooms?code=eq."+encodeURIComponent(roomCode)),{
      method:"PATCH", headers:agHeaders({"Prefer":"return=representation"}),
      body:JSON.stringify(body)
    });
    const data=await r.json().catch(()=>null);
    if(!r.ok) return {ok:false,error:{message:data?.message||data?.hint||("HTTP "+r.status),details:data}};
    return {ok:true,data:data?.[0]||data};
  } catch(e) { return {ok:false,error:{message:e.message}}; }
}

function agSubscribeRoom(roomCode,onChange) {
  if(agPollTimer) clearInterval(agPollTimer);
  let lastVersion=null;
  const poll=async()=>{
    const r=await agGetOnlineRoom(roomCode);
    if(r.ok && r.data?.state) {
      const v=r.data.state.version;
      if(lastVersion===null || v!==lastVersion) {
        lastVersion=v;
        onChange(r.data);
      }
    }
  };
  poll();
  agPollTimer=setInterval(poll,1000);
  return {unsubscribe:()=>clearInterval(agPollTimer)};
}

window.agSupabase = {
  __rest:true,
  from(){ throw new Error("Direct Supabase client disabled; use LIVE REST connector."); },
  removeChannel(){},
  channel(){ return null; }
};

