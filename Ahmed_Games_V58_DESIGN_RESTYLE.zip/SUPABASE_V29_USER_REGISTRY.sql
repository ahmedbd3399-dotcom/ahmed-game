-- Ahmed Games V29: dedicated username registry (optional for cross-device uniqueness)
-- This is NOT the rooms table. The app's V29 login works without this file.
-- To enforce one username globally across all devices, use a dedicated backend/RPC.
create table if not exists public.ag_users (
  username text primary key,
  display_name text not null default '',
  password_hash text not null,
  created_at timestamptz not null default now()
);
alter table public.ag_users enable row level security;

-- Do NOT expose password_hash with a public SELECT policy.
-- Use a server-side RPC/Edge Function for production authentication.
