
/* ================= AHMED GAMES SUPABASE AUTH ================= */
(function(){
  const C = window.AHMED_GAMES_CONFIG;
  const AUTH_BASE = C.url.replace(/\/+$/,"") + "/auth/v1";
  const STORAGE = "ag_supabase_session_v1";
  const EMAIL_KEY = "ag_saved_email";

  function headers(token){
    return {
      "apikey": C.publishableKey,
      "Authorization": "Bearer " + (token || C.publishableKey),
      "Content-Type":"application/json"
    };
  }

  function saveSession(session){
    if(!session) return;
    localStorage.setItem(STORAGE, JSON.stringify(session));
    if(session.access_token) window.AHMED_GAMES_AUTH_TOKEN=session.access_token;
    if(session.user){
      localStorage.setItem("ag_current", JSON.stringify(session.user));
      if(session.user.email) localStorage.setItem(EMAIL_KEY, session.user.email);
    }
  }

  function readSession(){
    try{return JSON.parse(localStorage.getItem(STORAGE)||"null");}catch(e){return null;}
  }

  async function authFetch(path, opts={}){
    const r=await fetch(AUTH_BASE+path, Object.assign({
      headers:headers(opts.token)
    },opts));
    const data=await r.json().catch(()=>null);
    if(!r.ok) throw new Error(data?.msg||data?.message||data?.error_description||data?.error||("HTTP "+r.status));
    return data;
  }

  async function refreshSession(session){
    if(!session?.refresh_token) return null;
    try{
      const data=await authFetch("/token?grant_type=refresh_token",{
        method:"POST",
        body:JSON.stringify({refresh_token:session.refresh_token})
      });
      saveSession(data);
      return data;
    }catch(e){
      localStorage.removeItem(STORAGE);
      localStorage.removeItem("ag_current");
      window.AHMED_GAMES_AUTH_TOKEN="";
      return null;
    }
  }

  async function restoreAuth(){
    await saveSdkSession();
    let s=readSession();
    if(!s) {
      const old=localStorage.getItem("ag_current");
      if(old) {
        try {
          const u=JSON.parse(old);
          if(u?.email) document.getElementById("email")?.setAttribute("value",u.email);
        }catch(e){}
      }
      window.renderUser?.();
      return;
    }

    const expired = s.expires_at && Date.now()/1000 > Number(s.expires_at)-60;
    if(expired) s=await refreshSession(s);
    if(!s) { window.renderUser?.(); return; }

    try{
      const user=await authFetch("/user",{token:s.access_token});
      s.user=user;
      saveSession(s);
    }catch(e){
      s=await refreshSession(s);
    }
    window.renderUser?.();
  }

  async function saveSdkSession(){
    try{
      const {data}=await supabaseClient.auth.getSession();
      const session=data?.session;
      if(session){
        saveSession(session);
        const u=session.user||{};
        localStorage.setItem("ag_current",JSON.stringify(u));
        localStorage.setItem("ag_auth_method",u.phone?"phone":(u.app_metadata?.provider||"google"));
        window.renderUser?.();
        document.getElementById("auth")?.classList.add("hidden");
        if(typeof window.setupIdentity==="function") window.setupIdentity();
        return session;
      }
    }catch(e){ console.warn("SDK session restore",e); }
    return null;
  }

  window.loginWithGoogle = async function(){
    const msg=document.getElementById("authMsg");
    try{
      if(msg)msg.textContent="جاري فتح Google...";
      const {error}=await supabaseClient.auth.signInWithOAuth({
        provider:"google",
        options:{redirectTo:window.location.href,queryParams:{prompt:"select_account"}}
      });
      if(error)throw error;
    }catch(e){if(msg)msg.textContent="تعذر تسجيل Google: "+(e.message||e);}
  };

  window.sendPhoneCode = async function(){
    const phone=(document.getElementById("phone")?.value||"").trim();
    const name=(document.getElementById("displayName")?.value||"").trim();
    const msg=document.getElementById("authMsg");
    if(!/^\+[1-9]\d{7,14}$/.test(phone)){if(msg)msg.textContent="اكتب رقم الهاتف بالصيغة الدولية مثل +2010xxxxxxxx";return;}
    try{
      const {error}=await supabaseClient.auth.signInWithOtp({phone,options:{shouldCreateUser:true,data:{name:name||"لاعب"}}});
      if(error)throw error;
      document.getElementById("phoneOtp")?.classList.remove("hidden");
      document.getElementById("verifyPhoneBtn")?.classList.remove("hidden");
      if(msg)msg.textContent="تم إرسال كود التحقق على الهاتف 📱";
    }catch(e){if(msg)msg.textContent="تعذر إرسال الكود: "+(e.message||e);}
  };

  window.verifyPhoneCode = async function(){
    const phone=(document.getElementById("phone")?.value||"").trim();
    const token=(document.getElementById("phoneOtp")?.value||"").trim();
    const msg=document.getElementById("authMsg");
    if(!token){if(msg)msg.textContent="اكتب كود التحقق.";return;}
    try{
      const {data,error}=await supabaseClient.auth.verifyOtp({phone,token,type:"sms"});
      if(error)throw error;
      if(data?.session)saveSession(data.session);
      await saveSdkSession();
      if(msg)msg.textContent="تم تسجيل الدخول وحفظ الحساب على الجهاز ✅";
    }catch(e){if(msg)msg.textContent="كود التحقق غير صحيح أو منتهي: "+(e.message||e);}
  };

  supabaseClient.auth.onAuthStateChange(async(event,session)=>{
    if(session){
      saveSession(session);
      localStorage.setItem("ag_current",JSON.stringify(session.user||{}));
      window.renderUser?.();
      if(event==="SIGNED_IN" || event==="INITIAL_SESSION"){
        document.getElementById("auth")?.classList.add("hidden");
        if(typeof window.setupIdentity==="function") window.setupIdentity();
      }
    }
  });

  window.submitAuth = async function(){
    const email=(document.getElementById("email")?.value||"").trim().toLowerCase();
    const pass=document.getElementById("password")?.value||"";
    const name=(document.getElementById("displayName")?.value||"").trim()||email.split("@")[0];
    const msg=document.getElementById("authMsg");
    if(!email||!pass){if(msg)msg.textContent="اكتب البريد وكلمة السر.";return;}
    if(!C?.url || !C?.publishableKey){if(msg)msg.textContent="إعداد Supabase ناقص.";return;}

    const btn=document.querySelector('#auth button[onclick="submitAuth()"]');
    if(btn){btn.disabled=true;btn.textContent="جاري الاتصال...";}
    try{
      let data;
      if(window.authKind==="signup"){
        data=await authFetch("/signup",{
          method:"POST",
          body:JSON.stringify({email,password:pass,data:{name:name}})
        });
        if(data.session){
          saveSession(data);
          if(msg)msg.textContent="تم إنشاء الحساب وتسجيل الدخول ✅";
          document.getElementById("auth")?.classList.add("hidden");
        }else{
          if(msg)msg.textContent="تم إنشاء الحساب. افتح بريدك وأكّد الحساب ثم سجّل الدخول. 📧";
        }
      }else{
        data=await authFetch("/token?grant_type=password",{
          method:"POST",
          body:JSON.stringify({email,password:pass})
        });
        saveSession(data);
        if(msg)msg.textContent="تم تسجيل الدخول ✅";
        document.getElementById("auth")?.classList.add("hidden");
      }
      window.renderUser?.();
      if(typeof window.setupIdentity==="function") window.setupIdentity();
    }catch(e){
      if(msg)msg.textContent="خطأ: "+e.message;
    }finally{
      if(btn){btn.disabled=false;btn.textContent="متابعة";}
    }
  };

  window.renderUser = function(){
    let u=null;
    try{u=JSON.parse(localStorage.getItem("ag_current")||"null");}catch(e){}
    const box=document.getElementById("userBox");
    if(!box)return;
    if(u){
      const n=u.user_metadata?.name||u.name||u.email?.split("@")[0]||"لاعب";
      box.innerHTML=`<span class="gold">👤 ${n}</span> <button class="dark" onclick="logout()">خروج</button>`;
      const email=document.getElementById("email");
      if(email&&!email.value)email.value=localStorage.getItem(EMAIL_KEY)||u.email||"";
    }else{
      box.innerHTML=`<button class="blue" onclick="showAuth()">تسجيل الدخول</button>`;
    }
  };

  window.logout = async function(){
    const s=readSession();
    try{
      if(s?.access_token) await authFetch("/logout",{method:"POST",token:s.access_token});
    }catch(e){}
    localStorage.removeItem(STORAGE);
    localStorage.removeItem("ag_current");
    window.AHMED_GAMES_AUTH_TOKEN="";
    window.renderUser?.();
    location.reload();
  };

  // Remember email only; never store the password.
  const savedEmail=localStorage.getItem(EMAIL_KEY);
  const emailInput=document.getElementById("email");
  if(emailInput && savedEmail && !emailInput.value) emailInput.value=savedEmail;

  // Refresh the session automatically so the user stays signed in.
  restoreAuth();
  setInterval(async()=>{
    const s=readSession();
    if(s?.expires_at && Date.now()/1000 > Number(s.expires_at)-120){
      await refreshSession(s);
    }
  },60000);
})();
