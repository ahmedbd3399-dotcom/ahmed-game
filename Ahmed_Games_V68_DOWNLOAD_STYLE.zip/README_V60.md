# Ahmed Games 2.0 — Competitive Rebuild

The main game UI is in `app/src/main/assets/index.html`.

Open **أحمد جيمز → التنافسية** and choose one of the new games, then create/join a room.

The existing Supabase room backend is reused. Run the existing SQL setup in `SUPABASE_V40_ROOMS.sql` if the rooms table is not already configured.
