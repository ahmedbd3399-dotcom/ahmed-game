# رفع Ahmed Games على GitHub وبناء APK

**مهم:** لا ترفع ملف ZIP نفسه إلى المستودع وتنتظر Actions أن يبنيه. يجب أن تكون ملفات المشروع نفسها موجودة في جذر المستودع، وبداخلها:

- `.github/workflows/android-apk.yml`
- `settings.gradle`
- `build.gradle`
- `app/build.gradle`
- `app/src/main/...`

بعد رفع الملفات، افتح تبويب **Actions** ثم شغّل **Build Ahmed Games APK**. بعد نجاح العملية ستجد ملف `Ahmed-Games-APK` في Artifacts.
