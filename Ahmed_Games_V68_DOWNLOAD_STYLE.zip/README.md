# Ahmed Games ⚽

Ahmed Games is an Android WebView game app with a competitive online mode and AI mode.

## GitHub Actions APK build

This repository is already configured to build the APK from GitHub Actions.

1. Put the **contents of this project** in the repository root. Do not upload the ZIP as a single file.
2. Open **Actions** on GitHub.
3. Select **Build Ahmed Games APK**.
4. Press **Run workflow** (or push to `main`/`master`).
5. Open the completed run and download the artifact named **Ahmed-Games-APK**.

The workflow installs Java 17 and Gradle 8.7, then runs `:app:assembleDebug` and uploads the generated `app-debug.apk`.

## Project

- App name: Ahmed Games
- Application ID: `com.ahmedgames.app`
- Version: `2.1.0`
- Min SDK: 23
- Target SDK: 35
- Compile SDK: 35
