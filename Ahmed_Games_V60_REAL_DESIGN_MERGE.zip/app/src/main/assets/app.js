// Ahmed Games - Main JavaScript App Logic

let audioEnabled = true;
let currentBidValue = 45;
let timerInterval = null;

// Web Audio API Synthesizer for sound effects
function playEffect(type) {
  if (!audioEnabled) return;
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);

    if (type === 'click') {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(400, ctx.currentTime);
      gain.gain.setValueAtTime(0.1, ctx.currentTime);
      osc.start();
      osc.stop(ctx.currentTime + 0.08);
    } else if (type === 'bid') {
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(600, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(900, ctx.currentTime + 0.15);
      gain.gain.setValueAtTime(0.15, ctx.currentTime);
      osc.start();
      osc.stop(ctx.currentTime + 0.15);
    }
  } catch (e) {
    console.log('Audio Context not available');
  }
}

// Switch Bottom Tabs
function switchTab(tabName) {
  playEffect('click');
  const views = ['home', 'games', 'create-room', 'live-room', 'leaderboard', 'settings'];
  views.forEach(v => {
    const el = document.getElementById(`view-${v}`);
    if (el) {
      el.classList.add('hidden');
      el.classList.remove('flex');
    }
  });

  const activeView = document.getElementById(`view-${tabName}`);
  if (activeView) {
    activeView.classList.remove('hidden');
    activeView.classList.add('flex');
  }

  // Update Nav Button colors
  document.querySelectorAll('.nav-btn').forEach(btn => {
    btn.classList.remove('text-yellow-400');
    btn.classList.add('hover:text-white');
  });

  const activeNav = document.getElementById(`nav-${tabName}`);
  if (activeNav) {
    activeNav.classList.add('text-yellow-400');
  }
}

// Open Game Setup Screen
function selectGame(gameTitle) {
  playEffect('click');
  document.getElementById('create-room-title').innerHTML = `<i class="fa-solid fa-sliders"></i> إعدادات غرفة: ${gameTitle}`;
  switchTab('create-room');
}

// Toggle Privacy
function setRoomPrivacy(type) {
  playEffect('click');
  const btnPub = document.getElementById('btn-priv-public');
  const btnPriv = document.getElementById('btn-priv-private');

  if (type === 'public') {
    btnPub.className = "py-2 text-xs font-black rounded-lg bg-yellow-500 text-black transition";
    btnPriv.className = "py-2 text-xs font-black rounded-lg text-gray-400 hover:text-white transition";
  } else {
    btnPriv.className = "py-2 text-xs font-black rounded-lg bg-yellow-500 text-black transition";
    btnPub.className = "py-2 text-xs font-black rounded-lg text-gray-400 hover:text-white transition";
  }
}

// Start Live Room Game
function startLiveRoom(e) {
  e.preventDefault();
  playEffect('click');
  const randomCode = Math.floor(1000 + Math.random() * 9000);
  document.getElementById('live-room-code').innerText = `#${randomCode}`;
  switchTab('live-room');
  startAuctionTimer();
}

// Exit Live Room
function exitLiveRoom() {
  playEffect('click');
  if (timerInterval) clearInterval(timerInterval);
  switchTab('games');
}

// Auction Timer Logic
function startAuctionTimer() {
  let timeLeft = 15;
  const timerEl = document.getElementById('auction-timer');
  if (timerInterval) clearInterval(timerInterval);

  timerInterval = setInterval(() => {
    timeLeft--;
    if (timerEl) timerEl.innerText = timeLeft;
    if (timeLeft <= 0) {
      clearInterval(timerInterval);
      alert('⏰ انتهى وقت المزايدة! فاز باللاعب Ahmed_User بمبلغ ' + currentBidValue + 'M $');
    }
  }, 1000);
}

// Place Bid Simulation
function placeBid(amount) {
  playEffect('bid');
  currentBidValue += amount;
  document.getElementById('current-bid').innerText = `${currentBidValue}M $`;
  document.getElementById('highest-bidder').innerText = `Ahmed_User (أنت)`;
  
  // Add to log
  const chatLog = document.getElementById('live-chat-log');
  const logEntry = document.createElement('div');
  logEntry.className = 'text-green-400 text-[11px] font-bold';
  logEntry.innerHTML = `<strong class="text-yellow-400">أنت:</strong> زدت السعر بمقدار +${amount}M $ (الإجمالي: ${currentBidValue}M $)`;
  chatLog.appendChild(logEntry);
  chatLog.scrollTop = chatLog.scrollHeight;

  // Reset timer on new bid
  startAuctionTimer();
}

// Modal Control
function showModal(modalId) {
  playEffect('click');
  document.getElementById(modalId).classList.remove('hidden');
}

function closeModal(modalId) {
  playEffect('click');
  document.getElementById(modalId).classList.add('hidden');
}

function submitJoinRoom() {
  const code = document.getElementById('room-code-input').value;
  if (code.length < 4) {
    alert('يرجى إدخال كود الغرفة المكون من 4 أرقام');
    return;
  }
  closeModal('join-room-modal');
  document.getElementById('live-room-code').innerText = `#${code}`;
  switchTab('live-room');
  startAuctionTimer();
}

function toggleAudio() {
  audioEnabled = !audioEnabled;
  const btn = document.getElementById('btn-sound');
  if (btn) {
    btn.innerHTML = audioEnabled ? '<i class="fa-solid fa-volume-high text-sm"></i>' : '<i class="fa-solid fa-volume-xmark text-sm"></i>';
  }
}

function openProfile() {
  const newName = prompt('أدخل اسمك الجديد:', 'Ahmed_User');
  if (newName) {
    document.getElementById('user-display-name').innerText = newName;
  }
}
