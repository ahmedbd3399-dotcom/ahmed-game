
/* ================= AHMED GAMES LIVE ONLINE MODE ================= */
(function(){
  let onlineRoomCode=null, onlineIsHost=false, onlinePlayerId=null;
  let onlinePlayerName="Ahmed", onlineState=null, onlineVersion=0, onlineTimer=null;

  function getUser(){
    try{return JSON.parse(localStorage.getItem("ag_current")||"null");}
    catch(e){return null;}
  }
  function ensurePlayerId(){
    let id=localStorage.getItem("ag_player_id");
    if(!id){
      id=(window.crypto&&crypto.randomUUID)?crypto.randomUUID():
        "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g,c=>{
          const r=Math.random()*16|0,v=c==="x"?r:(r&3|8);return v.toString(16);
        });
      localStorage.setItem("ag_player_id",id);
    }
    return id;
  }
  function setupIdentity(){
    const u=getUser(); onlinePlayerId=ensurePlayerId(); onlinePlayerName=u?.name||"Ahmed";
  }
  setupIdentity();

  function configured(){return window.agIsConfigured?window.agIsConfigured():(
    window.AHMED_GAMES_CONFIG?.url?.startsWith("https://") &&
    window.AHMED_GAMES_CONFIG?.publishableKey?.startsWith("sb_publishable_")
  );}

  function roomStateBase(code,modeValue){
    return {
      version:1,room_code:String(code),status:"waiting",
      host_id:onlinePlayerId,guest_id:null,host_name:onlinePlayerName,guest_name:null,
      mode:modeValue||window.mode||"5",budget:modeValue==="11"?200:100,
      maxPlayers:modeValue==="11"?11:5,phase:"lobby",turn:null,currentPlayerId:null,
      currentBid:1,lastBidderId:null,active:false,deadline:null,soldIds:[],
      hostTeam:[],guestTeam:[],hostMoney:modeValue==="11"?200:100,
      guestMoney:modeValue==="11"?200:100,auctionRound:0,hidden:modeValue==="hidden",
      lastMessage:"الغرفة اتعملت — مستني صاحبك يدخل."
    };
  }

  async function saveState(){
    if(!configured()||!onlineRoomCode||!onlineState)return false;
    onlineState.version=(onlineState.version||0)+1;
    const r=await agUpdateOnlineRoom(onlineRoomCode,onlineState);
    if(!r.ok){console.error(r.error);log?.("ai","❌ "+(r.error?.message||"فشل حفظ الغرفة"));return false;}
    onlineVersion=onlineState.version; return true;
  }

  function playerById(id){return(window.players||[]).find(p=>String(p.id)===String(id));}
  function teamForMe(s){return s.host_id===onlinePlayerId?(s.hostTeam||[]):(s.guestTeam||[]);}
  function teamForOpp(s){return s.host_id===onlinePlayerId?(s.guestTeam||[]):(s.hostTeam||[]);}
  function myTeam(){return teamForMe(onlineState);}

  function showLobby(s){
    document.getElementById("home")?.classList.add("hidden");
    document.getElementById("lobby")?.classList.remove("hidden");
    const rc=document.getElementById("roomCodeView"); if(rc)rc.textContent=s.room_code;
    const me=s.host_id===onlinePlayerId;
    const members=[];
    if(s.host_id)members.push(`<div class="member"><b>${s.host_name||"صاحب الغرفة"}</b><br><span class="success">● متصل</span></div>`);
    if(s.guest_id)members.push(`<div class="member"><b>${s.guest_name||"الضيف"}</b><br><span class="success">● متصل</span></div>`);
    else members.push(`<div class="member"><b>في انتظار اللاعب الثاني...</b><br><span class="muted">شارك كود الغرفة مع صاحبك</span></div>`);
    const rm=document.getElementById("roomMembers");if(rm)rm.innerHTML=members.join("");
    const rs=document.getElementById("roomState");if(rs)rs.textContent=s.guest_id?(me?"أنت صاحب الغرفة — اللاعب الثاني دخل.":"دخلت الغرفة — مستني صاحب الغرفة يبدأ."):"مستني صاحبك يدخل...";
    const btn=document.querySelector('#lobby button[onclick="beginRoom()"]');
    if(btn){btn.disabled=!me||!s.guest_id;btn.textContent=!s.guest_id?"مستني اللاعب الثاني...":(me?"ابدأ المزاد":"مستني صاحب الغرفة...");btn.style.opacity=btn.disabled?".55":"1";}
  }

  function subscribe(code){
    agSubscribeRoom(code,payload=>{
      if(payload?.state){
        onlineState=payload.state;onlineVersion=onlineState.version||0;applyOnlineState();
      }
    });
  }

  async function createRoomOnline(){
    if(!configured()){alert("بيانات Supabase غير جاهزة.");return;}
    setupIdentity();
    const code=String(Math.floor(100000+Math.random()*900000));
    const state=roomStateBase(code,window.mode||"5");
    const r=await agCreateOnlineRoom(code,state,onlinePlayerId);
    if(!r.ok){alert("فشل إنشاء الغرفة: "+(r.error?.message||"خطأ في الاتصال"));return;}
    onlineRoomCode=code;onlineIsHost=true;onlineState=r.data?.state||state;
    subscribe(code);showLobby(onlineState);
  }

  async function joinRoomOnline(){
    if(!configured()){alert("بيانات Supabase غير جاهزة.");return;}
    setupIdentity();
    const code=(document.getElementById("roomCodeInput")?.value||"").trim();
    if(!/^\d{6}$/.test(code)){alert("اكتب كود غرفة من 6 أرقام");return;}
    const r=await agGetOnlineRoom(code);
    if(!r.ok){alert("خطأ في الاتصال: "+(r.error?.message||""));return;}
    if(!r.data){alert("الغرفة غير موجودة.");return;}
    if(r.data.guest_id&&r.data.guest_id!==onlinePlayerId){alert("الغرفة مكتملة — لاعبان فقط.");return;}
    const s=r.data.state||{};
    if(s.status==="playing"||s.phase==="auction"){alert("المزاد بدأ بالفعل.");return;}
    s.guest_id=onlinePlayerId;s.guest_name=onlinePlayerName;s.status="ready";
    s.lastMessage=onlinePlayerName+" دخل الغرفة.";
    s.version=(s.version||0)+1;
    const upd=await agUpdateOnlineRoom(code,s,{guest_id:onlinePlayerId,status:"ready"});
    if(!upd.ok){alert("فشل دخول الغرفة: "+(upd.error?.message||""));return;}
    onlineRoomCode=code;onlineIsHost=false;onlineState=upd.data?.state||s;
    subscribe(code);showLobby(onlineState);
  }

  async function startOnlineAuction(){
    if(!onlineState||!onlineIsHost||!onlineState.guest_id)return;
    const list=window.players||[],pool=list.filter(p=>!(onlineState.soldIds||[]).includes(p.id));
    if(!pool.length)return;
    const p=pool[Math.floor(Math.random()*pool.length)];
    onlineState.status="playing";onlineState.phase="auction";onlineState.currentPlayerId=p.id;
    onlineState.currentBid=1;onlineState.lastBidderId=null;onlineState.turn=onlineState.host_id;
    onlineState.active=true;onlineState.deadline=Date.now()+20000;onlineState.auctionRound=1;
    onlineState.lastMessage="بدأ المزاد 🔨";await saveState();applyOnlineState();
  }

  function renderOnlineTeams(){
    const mine=myTeam(),opp=teamForOpp(onlineState);
    const teamBox=document.getElementById("team");
    if(teamBox)teamBox.innerHTML=mine.map(x=>`<div class="member">${x.img?`<img src="${x.img}" onerror="this.style.display='none'>`:"⚽"}<br><b>${x.name}</b><br><span class="muted">${x.cost||0}M</span></div>`).join("");
    const oppBox=document.getElementById("opponentTeam");
    if(oppBox)oppBox.innerHTML=opp.map(x=>`<div class="member">${x.img?`<img src="${x.img}" onerror="this.style.display='none'>`:"⚽"}<br><b>${x.name}</b><br><span class="muted">${x.pos||""} • ${x.rate||""}</span></div>`).join("");
    const m=document.getElementById("money");
    if(m)m.textContent=(onlineState.host_id===onlinePlayerId?(onlineState.hostMoney??onlineState.budget):(onlineState.guestMoney??onlineState.budget))+"M";
  }

  function renderOnlineAuction(){
    const p=playerById(onlineState.currentPlayerId);if(!p)return;
    window.current=p;window.currentBid=onlineState.currentBid||1;window.active=!!onlineState.active;
    window.lastBidder=onlineState.lastBidderId===onlinePlayerId?"أنت":onlineState.lastBidderId?
      (onlineState.lastBidderId===onlineState.host_id?onlineState.host_name:onlineState.guest_name):null;
    const card=document.getElementById("auctionCard");if(card&&typeof cardHTML==="function")card.innerHTML=cardHTML(p,true);
    if(onlineState.hidden){
      document.querySelector(".big-card .pc-name")?.replaceChildren(document.createTextNode("اللاعب الخفي"));
      document.querySelector(".big-card .pc-rate")?.replaceChildren(document.createTextNode("?"));
    }
    const price=document.getElementById("price");if(price)price.textContent=onlineState.currentBid+"M";
    const turn=document.getElementById("turn");if(turn)turn.textContent=onlineState.turn===onlinePlayerId&&onlineState.active?"دورك — زوّد الآن":(onlineState.active?"دور الخصم...":"انتهى المزاد");
    const b=document.getElementById("bid");if(b)b.value=Math.max((onlineState.currentBid||1)+1,1);
    const cb=document.querySelector('[onclick="claim()"]');if(cb)cb.disabled=!(onlineState.turn===onlinePlayerId&&onlineState.active&&onlineState.lastBidderId===onlinePlayerId);
    const pb=document.querySelector('[onclick="pass()"]');if(pb)pb.disabled=!(onlineState.turn===onlinePlayerId&&onlineState.active);
  }

  function applyOnlineState(){
    if(!onlineState)return;
    if(onlineState.phase==="lobby"){showLobby(onlineState);return;}
    document.getElementById("lobby")?.classList.add("hidden");
    document.getElementById("game")?.classList.remove("hidden");
    document.getElementById("teamPanel")?.classList.remove("hidden");
    document.getElementById("matchPanel")?.classList.remove("hidden");
    renderOnlineTeams();renderOnlineAuction();
    if(onlineTimer)clearInterval(onlineTimer);
    if(onlineState.active&&onlineState.deadline){
      onlineTimer=setInterval(()=>{
        const left=Math.max(0,Math.ceil((onlineState.deadline-Date.now())/1000));
        const t=document.getElementById("timer");if(t)t.textContent=left;
        if(left<=0){clearInterval(onlineTimer);if(onlineIsHost)onlineResolve("timeout");}
      },250);
    }
    if(onlineState.lastMessage&&typeof log==="function"){
      const key="ag_last_msg_"+onlineState.version;
      if(!sessionStorage.getItem(key)){sessionStorage.setItem(key,"1");log("info",onlineState.lastMessage);}
    }
  }

  async function onlineBid(value){
    if(!onlineState||!onlineState.active||onlineState.turn!==onlinePlayerId)return;
    value=parseInt(value);
    const money=onlineState.host_id===onlinePlayerId?(onlineState.hostMoney??onlineState.budget):(onlineState.guestMoney??onlineState.budget);
    if(!value||value<=onlineState.currentBid){log?.("ai","❌ لازم تزيد عن "+onlineState.currentBid+"M");return;}
    if(value>money){log?.("ai","❌ ميزانيتك لا تكفي.");return;}
    onlineState.currentBid=value;onlineState.lastBidderId=onlinePlayerId;
    onlineState.turn=onlinePlayerId===onlineState.host_id?onlineState.guest_id:onlineState.host_id;
    onlineState.lastMessage=onlinePlayerName+" زاد إلى "+value+"M 🔥";
    await saveState();applyOnlineState();
  }
  window.myBid=async function(){if(onlineState)await onlineBid(parseInt(document.getElementById("bid").value));};
  window.add=function(n){const b=document.getElementById("bid");if(b){b.value=(onlineState?.currentBid||1)+n;window.myBid();}};

  async function onlineResolve(reason){
    if(!onlineState||!onlineIsHost||!onlineState.active)return;
    const p=playerById(onlineState.currentPlayerId);if(!p)return;
    onlineState.active=false;onlineState.deadline=null;
    const winner=onlineState.lastBidderId;
    if(winner){
      const hostWon=winner===onlineState.host_id; const key=hostWon?"hostTeam":"guestTeam"; const moneyKey=hostWon?"hostMoney":"guestMoney";
      const money=onlineState[moneyKey]??onlineState.budget;
      onlineState[key]=onlineState[key]||[];onlineState[key].push({...p,cost:onlineState.currentBid});
      onlineState[moneyKey]=Math.max(0,money-onlineState.currentBid);
      onlineState.soldIds=onlineState.soldIds||[];onlineState.soldIds.push(p.id);
      onlineState.lastMessage=(hostWon?onlineState.host_name:onlineState.guest_name)+" كسب "+p.name+" بـ "+onlineState.currentBid+"M 🏆";
    }else{
      onlineState.soldIds=onlineState.soldIds||[];onlineState.soldIds.push(p.id);
      onlineState.lastMessage="انتهى الوقت بدون مزايدة.";
    }
    const myT=onlineState.host_id===onlinePlayerId?onlineState.hostTeam:onlineState.guestTeam;
    if((myT||[]).length>=onlineState.maxPlayers){onlineState.phase="finished";onlineState.status="finished";onlineState.turn=null;await saveState();applyOnlineState();return;}
    const pool=(window.players||[]).filter(x=>!(onlineState.soldIds||[]).includes(x.id));
    if(!pool.length){onlineState.phase="finished";onlineState.status="finished";onlineState.turn=null;await saveState();applyOnlineState();return;}
    const next=pool[Math.floor(Math.random()*pool.length)];
    onlineState.currentPlayerId=next.id;onlineState.currentBid=1;onlineState.lastBidderId=null;
    onlineState.turn=onlineState.host_id;onlineState.active=true;onlineState.deadline=Date.now()+20000;
    onlineState.auctionRound=(onlineState.auctionRound||0)+1;await saveState();applyOnlineState();
  }

  window.claim=async function(){
    if(!onlineState||onlineState.turn!==onlinePlayerId||!onlineState.lastBidderId){log?.("ai","⚠️ لازم تكون أعلى مزايد ودورك.");return;}
    await onlineResolve("claim");
  };
  window.pass=async function(){
    if(!onlineState||onlineState.turn!==onlinePlayerId)return;
    onlineState.turn=null;onlineState.active=false;onlineState.lastMessage=onlinePlayerName+" انسحب من المزايدة.";
    await saveState();if(onlineIsHost)await onlineResolve("pass");
  };
  window.createRoom=async function(){if(!getUser()){showAuth();return;}await createRoomOnline();};
  window.joinRoom=async function(){if(!getUser()){showAuth();return;}await joinRoomOnline();};
  window.openRoom=function(code,host){onlineRoomCode=String(code);onlineIsHost=!!host;setupIdentity();};
  window.beginRoom=async function(){if(!onlineIsHost){alert("صاحب الغرفة فقط يبدأ المزاد.");return;}if(!onlineState?.guest_id){alert("مستني اللاعب الثاني يدخل.");return;}document.getElementById("lobby")?.classList.add("hidden");await startOnlineAuction();};
  window.startAuction=async function(){if(onlineIsHost)await startOnlineAuction();};

  // Keep status visible and verify connectivity.
  async function setStatus(){
    const dot=document.getElementById("ag-online-dot"),text=document.getElementById("ag-online-text");
    if(!dot||!text)return;
    if(!configured()){dot.style.background="#f5a623";text.textContent="🟡 أونلاين: إعداد Supabase غير مكتمل";return;}
    const test=await agGetOnlineRoom("000000");
    if(test.ok || test.error?.message?.includes("No rows") || test.error?.details?.code==="PGRST116"){
      dot.style.background="#22c55e";text.textContent="🟢 أونلاين: Supabase متصل";
    }else{
      dot.style.background="#ef4444";text.textContent="🔴 أونلاين: خطأ اتصال";
    }
  }
  setTimeout(setStatus,500);
  window.AhmedGamesOnline={getState:()=>onlineState,getRoom:()=>onlineRoomCode};
})();
